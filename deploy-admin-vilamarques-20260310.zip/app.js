const STORAGE_KEY = "corporate-housing-proposal-v1";
const CLOUD_SYNC_ENDPOINT_KEY = "vm-cloud-sync-endpoint";
const SUPABASE_URL_KEY = "vm-supabase-url";
const SUPABASE_ANON_KEY = "vm-supabase-anon-key";
const LOCAL_TEST_SESSION_KEY = "vm-local-test-session";
const LOCAL_TEST_EMAIL = "teste@vila.com";
const LOCAL_TEST_PASSWORD = "123456";
const FIXED_LOGO_PATH = "./assets/logo-vila-marques.png";
const CONTRACTOR_INFO = {
  companyName: "Vila Marques Alojamentos",
  cnpj: "58.924.922/0001-75",
  responsible: "Fred Marques",
  phone: "(31) 99578-5160",
};
const DEFAULT_FURNITURE = [
  { item: "Geladeira", environment: "Cozinha" },
  { item: "Fogão", environment: "Cozinha" },
  { item: "Micro-ondas", environment: "Cozinha" },
  { item: "Armário", environment: "Cozinha" },
  { item: "Multiuso", environment: "Quarto" },
  { item: "Cama box", environment: "Quarto" },
  { item: "Colchão D33", environment: "Quarto" },
  { item: "Ventilador", environment: "Quarto" },
  { item: "TV Smart", environment: "Sala" },
  { item: "Varais", environment: "Área de serviço" },
  { item: "Tábua de passar", environment: "Área de serviço" },
  { item: "Ferro de passar", environment: "Área de serviço" },
  { item: "Sofá", environment: "Sala" },
  { item: "Máquina de lavar roupas", environment: "Área de serviço" },
  { item: "Papeleira", environment: "Banheiro" },
  { item: "Papeleira", environment: "Cozinha" },
  { item: "Porta-Copos", environment: "Cozinha" },
  { item: "Escova sanitária", environment: "Banheiro" },
  { item: "Mesa para 4 pessoas", environment: "Copa/Cozinha" },
  { item: "Mesa para 6 pessoas", environment: "Copa/Cozinha" },
];
const ENVIRONMENT_ORDER = [
  "Cozinha",
  "Copa/Cozinha",
  "Sala",
  "Quarto",
  "Banheiro",
  "Área de serviço",
  "Não informado",
];
const FURNITURE_VARIANTS = {
  "Cama box": {
    label: "Tipo",
    options: ["Solteiro", "Casal"],
  },
  Multiuso: {
    label: "Modelo",
    options: ["2 portas", "3 portas"],
  },
};

const state = {
  company: {},
  clients: [],
  property: {},
  furniture: [],
  proposalPhotos: [],
  pricing: {},
  proposal: {},
  payslip: {
    competence: "",
    paymentDate: "",
    paymentMethod: "",
    selectedEmployeeId: "",
    monthTotalDays: "30",
    businessDaysInMonth: "22",
    absenceDays: "0",
    allowanceDays: "0",
    employeeName: "",
    employeeCpf: "",
    position: "",
    registration: "",
    baseSalary: "0",
    mealAllowanceFixed: "0",
    mealAllowanceDaily: "0",
    fixedDiscountPercent: "0",
    earnings: [],
    discounts: [],
  },
  payslipEmployees: [],
  balance: {
    entries: [],
  },
  contracts: createEmptyContract(),
  contractsPortfolio: [],
  activeContractId: "",
  exports: [],
};
const uiState = {
  activeTab: "proposals",
  proposalStep: 1,
  maxProposalStep: 6,
  editingClientId: "",
  viewingClientId: "",
  editingEmployeeId: "",
  viewingEmployeeId: "",
  pendingEmployeeDocuments: [],
  clientsFormOpen: false,
  employeesFormOpen: false,
  payslipFormOpen: false,
  contractsSavedView: "effective",
  contractsFormOpen: false,
  contractsEditMode: false,
  contractsVisibleValuesById: {},
  contractsSummaryVisible: false,
  notificationsOpen: false,
  balanceMode: "monthly",
  balanceYear: new Date().getFullYear(),
  balanceMonth: new Date().getMonth() + 1,
  balanceContractId: "",
};

const authState = {
  client: null,
  user: null,
  mode: "none",
};

const currencyBRL = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
});
const CONTRACT_MONEY_FIELDS = [
  "dailyRatePerPerson",
  "rentCost",
  "staffCost",
  "furnitureCost",
  "cleaningProductsCost",
  "waterCost",
  "electricityCost",
  "internetCost",
  "maintenanceCost",
  "proLaboreCost",
];

function createEmptyContract() {
  return {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    contractName: "",
    accommodationAddress: "",
    accommodationStreet: "",
    accommodationNumber: "",
    accommodationComplement: "",
    accommodationDistrict: "",
    accommodationCity: "",
    accommodationState: "",
    accommodationZipCode: "",
    clientId: "",
    capacity: "0",
    dailyRatePerPerson: "0",
    monthlyTaxPercent: "0",
    measurementStartDay: "24",
    measurementEndDay: "24",
    receiptDay: "15",
    nextReceiptDateISO: "",
    receiptHistory: [],
    rentCost: "0",
    staffCost: "0",
    furnitureCost: "0",
    cleaningProductsCost: "0",
    waterCost: "0",
    electricityCost: "0",
    internetCost: "0",
    maintenanceCost: "0",
    proLaboreCost: "0",
    proLaboreRecipient: "",
    isEffective: false,
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  };
}

function escapeHtml(value) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function onlyDigits(value) {
  return String(value || "").replace(/\D/g, "");
}

function formatCNPJ(value) {
  const digits = onlyDigits(value).slice(0, 14);
  return digits
    .replace(/^(\d{2})(\d)/, "$1.$2")
    .replace(/^(\d{2})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1/$2")
    .replace(/(\d{4})(\d)/, "$1-$2");
}

function formatPhoneBR(value) {
  const digits = onlyDigits(value).slice(0, 11);
  if (digits.length <= 10) {
    return digits
      .replace(/^(\d{2})(\d)/, "($1) $2")
      .replace(/(\d{4})(\d)/, "$1-$2");
  }

  return digits
    .replace(/^(\d{2})(\d)/, "($1) $2")
    .replace(/(\d{5})(\d)/, "$1-$2");
}

function formatCEP(value) {
  const digits = onlyDigits(value).slice(0, 8);
  return digits.replace(/^(\d{5})(\d)/, "$1-$2");
}

function formatCPF(value) {
  const digits = onlyDigits(value).slice(0, 11);
  return digits
    .replace(/^(\d{3})(\d)/, "$1.$2")
    .replace(/^(\d{3})\.(\d{3})(\d)/, "$1.$2.$3")
    .replace(/\.(\d{3})(\d)/, ".$1-$2");
}

function formatRG(value) {
  const raw = String(value || "").toUpperCase().replace(/[^0-9X]/g, "");
  const xCount = (raw.match(/X/g) || []).length;
  const digitsOnly = raw.replace(/X/g, "").slice(0, 9);
  const normalized = xCount > 0
    ? `${digitsOnly.slice(0, 8)}X`
    : digitsOnly;
  const p1 = normalized.slice(0, 2);
  const p2 = normalized.slice(2, 5);
  const p3 = normalized.slice(5, 8);
  const p4 = normalized.slice(8, 9);
  let output = p1;
  if (p2) output += `.${p2}`;
  if (p3) output += `.${p3}`;
  if (p4) output += `-${p4}`;
  return output;
}

function fieldNameTokens(name) {
  const normalized = String(name || "")
    .replace(/([a-z])([A-Z])/g, "$1_$2")
    .toLowerCase();
  return normalized.split(/[^a-z0-9]+/).filter(Boolean);
}

function applyBrazilianInputPattern(input, phase = "input") {
  if (!input) return;
  const fieldName = String(input.name || "").trim();
  if (!fieldName) return;
  const tokens = fieldNameTokens(fieldName);
  const lowerName = fieldName.toLowerCase();

  if (tokens.includes("cnpj")) {
    input.value = formatCNPJ(input.value);
    return;
  }
  if (tokens.includes("cpf")) {
    input.value = formatCPF(input.value);
    return;
  }
  if (tokens.includes("rg")) {
    input.value = formatRG(input.value);
    return;
  }
  if (tokens.includes("cep") || lowerName.includes("zipcode")) {
    input.value = formatCEP(input.value);
    return;
  }
  if (tokens.includes("phone") || tokens.includes("telefone") || tokens.includes("celular")) {
    input.value = formatPhoneBR(input.value);
    return;
  }
  if (tokens.includes("state") || tokens.includes("uf")) {
    input.value = String(input.value || "")
      .toUpperCase()
      .replace(/[^A-Z]/g, "")
      .slice(0, 2);
    return;
  }
  if (tokens.includes("email") && phase === "blur") {
    input.value = String(input.value || "").trim().toLowerCase();
  }
}

function formatDateBR(value) {
  if (!value) return "-";
  const parts = value.split("-");
  if (parts.length !== 3) return value;
  return `${parts[2]}/${parts[1]}/${parts[0]}`;
}

function normalizeDayOfMonth(value, fallback = 1) {
  const day = Number(value || 0);
  if (!Number.isFinite(day)) return String(fallback);
  return String(Math.max(1, Math.min(31, Math.trunc(day))));
}

function parseBRLNumber(value) {
  let str = String(value ?? "").trim();
  if (!str) return 0;
  str = str.replace(/[^\d,.-]/g, "");
  if (!str) return 0;

  if (str.includes(",") && str.includes(".")) {
    if (str.lastIndexOf(",") > str.lastIndexOf(".")) {
      str = str.replace(/\./g, "").replace(",", ".");
    } else {
      str = str.replace(/,/g, "");
    }
  } else if (str.includes(",")) {
    str = str.replace(/\./g, "").replace(",", ".");
  }

  const parsed = Number(str);
  return Number.isFinite(parsed) ? parsed : 0;
}

function formatBRLInputValue(value) {
  return currencyBRL.format(parseBRLNumber(value));
}

function fileToDataUrl(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result || ""));
    reader.onerror = () => reject(new Error("Falha ao ler arquivo de imagem."));
    reader.readAsDataURL(file);
  });
}

async function addProposalPhotosFromFiles(files) {
  const imageFiles = Array.from(files || []).filter((file) => file.type.startsWith("image/"));
  if (!imageFiles.length) return 0;

  const nextPhotos = [];
  for (const file of imageFiles) {
    const dataUrl = await fileToDataUrl(file);
    nextPhotos.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name: file.name || "foto",
      dataUrl,
    });
  }

  state.proposalPhotos.push(...nextPhotos);
  saveState();
  renderAll();
  return nextPhotos.length;
}

function formatFileSize(bytes) {
  const size = Number(bytes || 0);
  if (size <= 0) return "0 B";
  if (size < 1024) return `${size} B`;
  if (size < 1024 * 1024) return `${(size / 1024).toFixed(1)} KB`;
  return `${(size / (1024 * 1024)).toFixed(1)} MB`;
}

function downloadBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = filename;
  document.body.appendChild(anchor);
  anchor.click();
  anchor.remove();
  URL.revokeObjectURL(url);
}

function downloadTextFile(filename, content, mimeType = "text/plain;charset=utf-8") {
  const blob = new Blob([content], { type: mimeType });
  downloadBlob(filename, blob);
}

async function addEmployeeDocumentsFromFiles(files) {
  const list = Array.from(files || []);
  if (!list.length) return 0;

  const docs = [];
  for (const file of list) {
    const dataUrl = await fileToDataUrl(file);
    docs.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      name: String(file.name || "arquivo").trim() || "arquivo",
      type: String(file.type || "").trim(),
      size: Number(file.size || 0),
      dataUrl,
    });
  }

  uiState.pendingEmployeeDocuments.push(...docs);
  renderPendingEmployeeDocuments();
  return docs.length;
}

function canonicalFurnitureItemName(item) {
  const raw = String(item || "").trim();
  const lower = raw.toLowerCase();
  if (lower === "armário multiuso" || lower === "armario multiuso") {
    return "Multiuso";
  }
  return raw;
}

function applyBRLMask(input) {
  if (!input) return;
  const digits = onlyDigits(input.value);
  const amount = Number(digits || 0) / 100;
  input.value = currencyBRL.format(amount);
}

function setupBRLInputs(container) {
  if (!container) return;
  container.querySelectorAll("input[data-brl]").forEach((input) => {
    if (input.dataset.brlBound === "1") return;
    input.dataset.brlBound = "1";
    if (!String(input.value || "").trim()) input.value = "R$ 0,00";
    input.addEventListener("input", () => applyBRLMask(input));
    input.addEventListener("blur", () => {
      input.value = formatBRLInputValue(input.value);
    });
  });
}

function normalizeContract(contract) {
  const base = { ...createEmptyContract(), ...(contract || {}) };
  const legacyAddress = String(base.accommodationAddress || "").trim();
  const measurementStartDay = normalizeDayOfMonth(base.measurementStartDay, 24);
  const measurementEndDay = normalizeDayOfMonth(base.measurementEndDay, 24);
  const receiptDay = normalizeDayOfMonth(base.receiptDay, 15);
  const fallbackReceiptISO = calculateContractTimeline({
    ...base,
    measurementStartDay,
    measurementEndDay,
    receiptDay,
  }).receiptDateISO;
  const nextReceiptDateISO = String(base.nextReceiptDateISO || "").trim() || fallbackReceiptISO;
  const receiptHistory = (Array.isArray(base.receiptHistory) ? base.receiptHistory : [])
    .map((entry) => ({
      id: String(entry.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
      dueDateISO: String(entry.dueDateISO || "").trim(),
      paymentDateISO: String(entry.paymentDateISO || "").trim(),
      createdAt: String(entry.createdAt || new Date().toISOString()),
    }))
    .filter((entry) => entry.dueDateISO && entry.paymentDateISO);
  return {
    ...base,
    id: String(base.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
    contractName: String(base.contractName || "").trim(),
    accommodationAddress: legacyAddress,
    accommodationStreet: String(base.accommodationStreet || legacyAddress).trim(),
    accommodationNumber: String(base.accommodationNumber || "").trim(),
    accommodationComplement: String(base.accommodationComplement || "").trim(),
    accommodationDistrict: String(base.accommodationDistrict || "").trim(),
    accommodationCity: String(base.accommodationCity || "").trim(),
    accommodationState: String(base.accommodationState || "")
      .toUpperCase()
      .replace(/[^A-Z]/g, "")
      .slice(0, 2),
    accommodationZipCode: formatCEP(base.accommodationZipCode || ""),
    clientId: String(base.clientId || "").trim(),
    capacity: String(Number(base.capacity || 0)),
    dailyRatePerPerson: String(parseBRLNumber(base.dailyRatePerPerson || 0)),
    monthlyTaxPercent: String(Number(base.monthlyTaxPercent || 0)),
    measurementStartDay,
    measurementEndDay,
    receiptDay,
    nextReceiptDateISO,
    receiptHistory,
    rentCost: String(parseBRLNumber(base.rentCost || 0)),
    staffCost: String(parseBRLNumber(base.staffCost || 0)),
    furnitureCost: String(parseBRLNumber(base.furnitureCost || 0)),
    cleaningProductsCost: String(parseBRLNumber(base.cleaningProductsCost || 0)),
    waterCost: String(parseBRLNumber(base.waterCost || 0)),
    electricityCost: String(parseBRLNumber(base.electricityCost || 0)),
    internetCost: String(parseBRLNumber(base.internetCost || 0)),
    maintenanceCost: String(parseBRLNumber(base.maintenanceCost || 0)),
    proLaboreCost: String(parseBRLNumber(base.proLaboreCost || 0)),
    proLaboreRecipient: String(base.proLaboreRecipient || "").trim(),
    isEffective: Boolean(base.isEffective),
    createdAt: String(base.createdAt || new Date().toISOString()),
    updatedAt: String(base.updatedAt || new Date().toISOString()),
  };
}

function hasContractContent(contract) {
  if (!contract) return false;
  if (String(contract.contractName || "").trim()) return true;
  if (String(contract.accommodationAddress || "").trim()) return true;
  if (String(contract.accommodationStreet || "").trim()) return true;
  if (String(contract.accommodationNumber || "").trim()) return true;
  if (String(contract.accommodationComplement || "").trim()) return true;
  if (String(contract.accommodationDistrict || "").trim()) return true;
  if (String(contract.accommodationCity || "").trim()) return true;
  if (String(contract.accommodationState || "").trim()) return true;
  if (String(contract.accommodationZipCode || "").trim()) return true;
  if (String(contract.clientId || "").trim()) return true;
  if (String(contract.proLaboreRecipient || "").trim()) return true;
  if (Number(contract.capacity || 0) > 0) return true;
  if (Number(parseBRLNumber(contract.dailyRatePerPerson || 0)) > 0) return true;
  return CONTRACT_MONEY_FIELDS
    .filter((field) => field !== "dailyRatePerPerson")
    .some((field) => Number(parseBRLNumber(contract[field] || 0)) > 0);
}

function ensureContractsPortfolio() {
  if (!Array.isArray(state.contractsPortfolio)) state.contractsPortfolio = [];
  state.contractsPortfolio = state.contractsPortfolio
    .map((item) => normalizeContract(item))
    .filter((item) => hasContractContent(item));

  if (!state.contractsPortfolio.length) {
    state.activeContractId = "";
    state.contracts = normalizeContract(state.contracts || createEmptyContract());
    return;
  }

  const active = state.contractsPortfolio.find((item) => item.id === state.activeContractId);
  if (active) {
    state.contracts = { ...active };
    return;
  }

  if (!state.activeContractId) {
    state.contracts = normalizeContract(state.contracts || createEmptyContract());
    return;
  }

  state.activeContractId = state.contractsPortfolio[0].id;
  state.contracts = { ...state.contractsPortfolio[0] };
}

function getActiveContractRecord() {
  ensureContractsPortfolio();
  if (!state.activeContractId) return null;
  return state.contractsPortfolio.find((item) => item.id === state.activeContractId) || null;
}

function setActiveContractById(contractId) {
  ensureContractsPortfolio();
  const target = state.contractsPortfolio.find((item) => item.id === contractId);
  if (!target) return;
  state.activeContractId = target.id;
  state.contracts = { ...target };
}

function persistActiveContract(data) {
  ensureContractsPortfolio();
  const active = getActiveContractRecord();
  const normalized = normalizeContract({
    ...(active || createEmptyContract()),
    ...(data || {}),
    id: state.activeContractId || active?.id,
    updatedAt: new Date().toISOString(),
  });
  const idx = state.contractsPortfolio.findIndex((item) => item.id === normalized.id);
  if (idx >= 0) state.contractsPortfolio[idx] = normalized;
  else state.contractsPortfolio.push(normalized);
  state.activeContractId = normalized.id;
  state.contracts = { ...normalized };
}

function loadState() {
  const raw = localStorage.getItem(STORAGE_KEY);
  if (!raw) return;

  try {
    const data = JSON.parse(raw);
    state.company = data.company || {};
    state.clients = Array.isArray(data.clients) ? data.clients : [];
    state.property = data.property || {};
    state.furniture = data.furniture || [];
    state.proposalPhotos = data.proposalPhotos || [];
    state.pricing = data.pricing || {};
    state.proposal = data.proposal || {};
    state.payslip = {
      ...state.payslip,
      ...(data.payslip || {}),
      earnings: (data.payslip && data.payslip.earnings) || [],
      discounts: (data.payslip && data.payslip.discounts) || [],
    };
    state.payslipEmployees = Array.isArray(data.payslipEmployees) ? data.payslipEmployees : [];
    state.balance = {
      ...state.balance,
      ...(data.balance || {}),
      entries: (data.balance && data.balance.entries) || [],
    };
    state.contracts = {
      ...state.contracts,
      ...(data.contracts || {}),
    };
    state.contractsPortfolio = Array.isArray(data.contractsPortfolio) ? data.contractsPortfolio : [];
    state.activeContractId = String(data.activeContractId || "").trim();
    state.exports = Array.isArray(data.exports) ? data.exports : [];
  } catch {
    localStorage.removeItem(STORAGE_KEY);
  }
}

function normalizeStatePatterns() {
  state.company.cnpj = formatCNPJ(state.company.cnpj);
  state.company.phone = formatPhoneBR(state.company.phone);
  state.company.email = String(state.company.email || "").trim().toLowerCase();
  state.property.zipCode = formatCEP(state.property.zipCode);
  state.property.state = String(state.property.state || "")
    .toUpperCase()
    .replace(/[^A-Z]/g, "")
    .slice(0, 2);

  const day = Number(state.proposal.paymentDay || 0);
  state.proposal.paymentDay = day >= 1 && day <= 31 ? String(day) : "";

  state.payslip.employeeCpf = formatCPF(state.payslip.employeeCpf);
  state.payslip.paymentMethod = String(state.payslip.paymentMethod || "").trim();
  state.payslip.selectedEmployeeId = String(state.payslip.selectedEmployeeId || "").trim();
  state.payslip.monthTotalDays = String(Number(state.payslip.monthTotalDays || 30));
  state.payslip.businessDaysInMonth = String(Number(state.payslip.businessDaysInMonth || 0));
  state.payslip.absenceDays = String(Number(state.payslip.absenceDays || 0));
  state.payslip.allowanceDays = String(Number(state.payslip.allowanceDays || 0));
  state.payslip.mealAllowanceFixed = String(parseBRLNumber(state.payslip.mealAllowanceFixed || 0));
  state.payslip.mealAllowanceDaily = String(parseBRLNumber(state.payslip.mealAllowanceDaily || 0));
  state.payslip.fixedDiscountPercent = String(Number(state.payslip.fixedDiscountPercent || 0));
  state.payslip.earnings = (state.payslip.earnings || []).map((item) => ({
    description: String(item.description || "").trim(),
    value: Number(item.value || 0),
  })).filter((item) => item.description);
  state.payslip.discounts = (state.payslip.discounts || []).map((item) => ({
    description: String(item.description || "").trim(),
    value: Number(item.value || 0),
  })).filter((item) => item.description);

  state.payslipEmployees = (state.payslipEmployees || [])
    .map((employee) => ({
      id: String(employee.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
      employeeName: String(employee.employeeName || "").trim(),
      employeeCpf: formatCPF(employee.employeeCpf),
      position: String(employee.position || "").trim(),
      registration: String(employee.registration || "").trim(),
      baseSalary: String(parseBRLNumber(employee.baseSalary || 0)),
      mealAllowanceFixed: String(parseBRLNumber(employee.mealAllowanceFixed || 0)),
      mealAllowanceDaily: String(parseBRLNumber(employee.mealAllowanceDaily || 0)),
      fixedDiscountPercent: String(Number(employee.fixedDiscountPercent || 0)),
      documents: (employee.documents || [])
        .map((doc) => ({
          id: String(doc.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
          name: String(doc.name || "arquivo").trim() || "arquivo",
          type: String(doc.type || "").trim(),
          size: Number(doc.size || 0),
          dataUrl: String(doc.dataUrl || "").trim(),
        }))
        .filter((doc) => doc.dataUrl),
    }))
    .filter((employee) => employee.employeeName);

  state.clients = (state.clients || [])
    .map((client) => ({
      id: String(client.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
      clientName: String(client.clientName || "").trim(),
      clientCnpj: formatCNPJ(client.clientCnpj || ""),
      clientContact: String(client.clientContact || "").trim(),
      clientPhone: formatPhoneBR(client.clientPhone || ""),
      clientEmail: String(client.clientEmail || "").trim().toLowerCase(),
      clientStreet: String(client.clientStreet || "").trim(),
      clientNumber: String(client.clientNumber || "").trim(),
      clientComplement: String(client.clientComplement || "").trim(),
      clientDistrict: String(client.clientDistrict || "").trim(),
      clientCity: String(client.clientCity || "").trim(),
      clientState: String(client.clientState || "")
        .toUpperCase()
        .replace(/[^A-Z]/g, "")
        .slice(0, 2),
      clientZipCode: formatCEP(client.clientZipCode || ""),
      clientNotes: String(client.clientNotes || "").trim(),
    }))
    .filter((client) => client.clientName);
  const clientIds = new Set(state.clients.map((client) => client.id));
  state.company.clientId = clientIds.has(String(state.company.clientId || "")) ? String(state.company.clientId || "") : "";

  state.balance.entries = (state.balance.entries || []).map((entry) => ({
    id: String(entry.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
    type: entry.type === "expense" ? "expense" : "income",
    description: String(entry.description || "").trim(),
    amount: Number(entry.amount || 0),
    dateTime: String(entry.dateTime || "").trim(),
    responsible: String(entry.responsible || "").trim(),
    contractId: String(entry.contractId || "").trim(),
  })).filter((entry) => entry.description && entry.amount >= 0 && entry.dateTime);

  state.furniture = (state.furniture || []).map((item) => ({
    item: canonicalFurnitureItemName(item.item),
    environment: String(item.environment || "Não informado").trim(),
    quantity: Number(item.quantity || 0),
    notes: String(item.notes || "").trim(),
  })).filter((item) => item.item && item.quantity > 0);
  state.proposalPhotos = (state.proposalPhotos || [])
    .map((photo) => ({
      id: String(photo.id || `${Date.now()}-${Math.random().toString(16).slice(2)}`),
      name: String(photo.name || "foto").trim() || "foto",
      dataUrl: String(photo.dataUrl || "").trim(),
    }))
    .filter((photo) => photo.dataUrl.startsWith("data:image/"));

  const legacyContract = normalizeContract(state.contracts);
  state.contractsPortfolio = (state.contractsPortfolio || [])
    .map((item) => normalizeContract(item))
    .map((item) => ({
      ...item,
      clientId: clientIds.has(String(item.clientId || "")) ? String(item.clientId || "") : "",
    }))
    .filter((item) => hasContractContent(item));
  if (!state.contractsPortfolio.length) {
    state.activeContractId = "";
    state.contracts = legacyContract;
    return;
  }
  const selected = state.contractsPortfolio.find((item) => item.id === state.activeContractId);
  if (selected) {
    state.contracts = { ...selected };
  } else {
    state.activeContractId = state.contractsPortfolio[0].id;
    state.contracts = { ...state.contractsPortfolio[0] };
  }
  if (!clientIds.has(String(state.contracts.clientId || ""))) {
    state.contracts.clientId = "";
  }

  state.exports = (state.exports || [])
    .map((item) => ({
      id: String(item.id || ""),
      type: item.type === "payslip" ? "payslip" : "proposal",
      exportedAt: String(item.exportedAt || ""),
      proposalNumber: String(item.proposalNumber || "").trim(),
      companyName: String(item.companyName || "").trim(),
      snapshot: item.snapshot || {},
      cloudStatus: String(item.cloudStatus || "pending"),
    }))
    .filter((item) => item.id && item.exportedAt);
}

function saveState() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
}

function getCloudSyncEndpoint() {
  return String(localStorage.getItem(CLOUD_SYNC_ENDPOINT_KEY) || "").trim();
}

function setCloudSyncEndpoint(value) {
  const endpoint = String(value || "").trim();
  if (endpoint) {
    localStorage.setItem(CLOUD_SYNC_ENDPOINT_KEY, endpoint);
  } else {
    localStorage.removeItem(CLOUD_SYNC_ENDPOINT_KEY);
  }
}

function getSupabaseConfig() {
  return {
    url: String(localStorage.getItem(SUPABASE_URL_KEY) || "").trim(),
    anonKey: String(localStorage.getItem(SUPABASE_ANON_KEY) || "").trim(),
  };
}

function setSupabaseConfig(url, anonKey) {
  const nextUrl = String(url || "").trim();
  const nextAnon = String(anonKey || "").trim();
  if (nextUrl) localStorage.setItem(SUPABASE_URL_KEY, nextUrl);
  else localStorage.removeItem(SUPABASE_URL_KEY);
  if (nextAnon) localStorage.setItem(SUPABASE_ANON_KEY, nextAnon);
  else localStorage.removeItem(SUPABASE_ANON_KEY);
}

function getLocalTestSession() {
  return localStorage.getItem(LOCAL_TEST_SESSION_KEY) === "1";
}

function setLocalTestSession(active) {
  if (active) localStorage.setItem(LOCAL_TEST_SESSION_KEY, "1");
  else localStorage.removeItem(LOCAL_TEST_SESSION_KEY);
}

function setAuthMessage(message, isError = false) {
  const container = document.getElementById("authMessage");
  if (!container) return;
  container.textContent = message || "";
  container.style.color = isError ? "#b91c1c" : "#334155";
}

function showAppShell(show) {
  const authGate = document.getElementById("authGate");
  const appShell = document.getElementById("appShell");
  if (!authGate || !appShell) return;
  authGate.style.display = show ? "none" : "";
  appShell.classList.toggle("app-shell-hidden", !show);
}

function switchAuthTab(tab) {
  const tabLogin = document.getElementById("authTabLogin");
  const tabSignup = document.getElementById("authTabSignup");
  const tabForgot = document.getElementById("authTabForgot");
  const loginForm = document.getElementById("loginForm");
  const signupForm = document.getElementById("signupForm");
  const forgotForm = document.getElementById("forgotForm");
  const resetForm = document.getElementById("resetForm");
  if (!tabLogin || !tabSignup || !tabForgot || !loginForm || !signupForm || !forgotForm || !resetForm) return;

  const active = tab === "reset" ? "forgot" : tab;
  tabLogin.classList.toggle("tab-btn-active", active === "login");
  tabSignup.classList.toggle("tab-btn-active", active === "signup");
  tabForgot.classList.toggle("tab-btn-active", active === "forgot");

  loginForm.classList.toggle("auth-hidden", tab !== "login");
  signupForm.classList.toggle("auth-hidden", tab !== "signup");
  forgotForm.classList.toggle("auth-hidden", tab !== "forgot");
  resetForm.classList.toggle("auth-hidden", tab !== "reset");
}

function setModulesMenuOpen(isOpen) {
  const menu = document.getElementById("modulesMenu");
  if (!menu) return;
  menu.classList.toggle("modules-menu-hidden", !isOpen);
}

function toggleSupabaseConfig(forceShow) {
  const form = document.getElementById("authConfigForm");
  if (!form) return;
  const shouldShow = typeof forceShow === "boolean"
    ? forceShow
    : form.classList.contains("auth-hidden");
  form.classList.toggle("auth-hidden", !shouldShow);
}

function getRedirectUrl() {
  return `${window.location.origin}${window.location.pathname}`;
}

async function initAuthClient() {
  const config = getSupabaseConfig();
  const cfgUrlInput = document.getElementById("supabaseUrlInput");
  const cfgAnonInput = document.getElementById("supabaseAnonKeyInput");
  if (cfgUrlInput) cfgUrlInput.value = config.url;
  if (cfgAnonInput) cfgAnonInput.value = config.anonKey;

  authState.client = null;
  authState.user = null;
  authState.mode = "none";

  if (getLocalTestSession()) {
    authState.mode = "local";
    authState.user = { email: LOCAL_TEST_EMAIL };
    showAppShell(true);
    setAuthMessage("Acesso de teste local ativo.");
    return;
  }

  if (!config.url || !config.anonKey) {
    setAuthMessage("Preencha Supabase URL e Anon Key para habilitar o login.", true);
    showAppShell(false);
    return;
  }

  if (!window.supabase || !window.supabase.createClient) {
    setAuthMessage("Biblioteca Supabase não carregada.", true);
    showAppShell(false);
    return;
  }

  authState.client = window.supabase.createClient(config.url, config.anonKey);
  authState.mode = "supabase";
  const { data } = await authState.client.auth.getSession();
  authState.user = data.session ? data.session.user : null;

  authState.client.auth.onAuthStateChange((_event, session) => {
    authState.user = session ? session.user : null;
    showAppShell(Boolean(authState.user));
  });

  const hash = window.location.hash || "";
  if (hash.includes("type=recovery")) {
    switchAuthTab("reset");
    setAuthMessage("Defina sua nova senha.");
    showAppShell(false);
    return;
  }

  showAppShell(Boolean(authState.user));
  if (!authState.user) {
    switchAuthTab("login");
    setAuthMessage("Faça login para continuar.");
  }
}

async function syncExportToCloud(exportRecord) {
  const endpoint = getCloudSyncEndpoint();
  if (!endpoint) return false;

  try {
    const response = await fetch(endpoint, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(exportRecord),
      keepalive: true,
    });
    return response.ok;
  } catch {
    return false;
  }
}

function cloneSnapshot(data) {
  return JSON.parse(JSON.stringify(data));
}

function registerExport(type) {
  const exportRecord = {
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    type,
    exportedAt: new Date().toISOString(),
    proposalNumber: String(state.proposal.proposalNumber || "").trim(),
    companyName: String(state.company.name || "").trim(),
    snapshot: cloneSnapshot({
      company: state.company,
      clients: state.clients,
      property: state.property,
      furniture: state.furniture,
      proposalPhotos: state.proposalPhotos,
      pricing: state.pricing,
      proposal: state.proposal,
      payslip: state.payslip,
      balance: state.balance,
      contracts: state.contracts,
    }),
    cloudStatus: "pending",
  };

  state.exports = [exportRecord, ...(state.exports || [])].slice(0, 500);
  saveState();
  renderExports();

  void syncExportToCloud(exportRecord).then((ok) => {
    const idx = state.exports.findIndex((item) => item.id === exportRecord.id);
    if (idx < 0) return;
    state.exports[idx].cloudStatus = ok ? "synced" : "failed";
    saveState();
    renderExports();
  });
}

function resetActiveTabInputs() {
  if (uiState.activeTab === "proposals") {
    state.company = {};
    state.property = {};
    state.furniture = [];
    state.proposalPhotos = [];
    state.pricing = {};
    state.proposal = {};
    return;
  }

  if (uiState.activeTab === "payslip") {
    state.payslip = {
      competence: "",
      paymentDate: "",
      paymentMethod: "",
      selectedEmployeeId: "",
      monthTotalDays: "30",
      businessDaysInMonth: "22",
      absenceDays: "0",
      allowanceDays: "0",
      employeeName: "",
      employeeCpf: "",
      position: "",
      registration: "",
      baseSalary: "0",
      mealAllowanceFixed: "0",
      mealAllowanceDaily: "0",
      fixedDiscountPercent: "0",
      earnings: [],
      discounts: [],
    };
    uiState.payslipFormOpen = false;
    return;
  }

  if (uiState.activeTab === "clients") {
    uiState.editingClientId = "";
    uiState.viewingClientId = "";
    uiState.clientsFormOpen = false;
    return;
  }

  if (uiState.activeTab === "employees") {
    uiState.editingEmployeeId = "";
    uiState.viewingEmployeeId = "";
    uiState.employeesFormOpen = false;
    return;
  }

  if (uiState.activeTab === "balance") {
    state.balance = { entries: [] };
    return;
  }

  if (uiState.activeTab === "contracts") {
    resetContractsDraftForm(false);
    uiState.contractsFormOpen = false;
  }
}

function resetModuleUiState(moduleName) {
  if (moduleName === "proposals") {
    uiState.proposalStep = 1;
    return;
  }

  if (moduleName === "clients") {
    uiState.clientsFormOpen = false;
    uiState.editingClientId = "";
    uiState.viewingClientId = "";
    return;
  }

  if (moduleName === "employees") {
    uiState.employeesFormOpen = false;
    uiState.editingEmployeeId = "";
    uiState.viewingEmployeeId = "";
    uiState.pendingEmployeeDocuments = [];
    return;
  }

  if (moduleName === "payslip") {
    uiState.payslipFormOpen = false;
    return;
  }

  if (moduleName === "contracts") {
    uiState.contractsFormOpen = false;
    uiState.contractsEditMode = false;
    uiState.contractsSummaryVisible = false;
    uiState.contractsSavedView = "effective";
    uiState.contractsVisibleValuesById = {};
    return;
  }

  if (moduleName === "balance") {
    uiState.balanceMode = "monthly";
    uiState.balanceContractId = "";
  }
}

function setActiveTab(tabName) {
  const previousTab = uiState.activeTab;
  const nextTab = ["proposals", "clients", "employees", "payslip", "balance", "contracts", "exports"].includes(tabName)
    ? tabName
    : "proposals";
  if (previousTab && previousTab !== nextTab) {
    resetModuleUiState(previousTab);
  }
  uiState.activeTab = nextTab;

  const proposalModule = document.getElementById("proposalModule");
  const clientsModule = document.getElementById("clientsModule");
  const employeesModule = document.getElementById("employeesModule");
  const payslipModule = document.getElementById("payslipModule");
  const balanceModule = document.getElementById("balanceModule");
  const contractsModule = document.getElementById("contractsModule");
  const exportsModule = document.getElementById("exportsModule");
  const tabProposals = document.getElementById("tabProposals");
  const tabClients = document.getElementById("tabClients");
  const tabEmployees = document.getElementById("tabEmployees");
  const tabPayslip = document.getElementById("tabPayslip");
  const tabBalance = document.getElementById("tabBalance");
  const tabContracts = document.getElementById("tabContracts");
  const tabExports = document.getElementById("tabExports");
  const btnExportProposal = document.getElementById("btnExportPdf");
  const btnExportPayslip = document.getElementById("btnExportPayslipPdf");

  proposalModule.classList.toggle("module-active", uiState.activeTab === "proposals");
  clientsModule.classList.toggle("module-active", uiState.activeTab === "clients");
  employeesModule.classList.toggle("module-active", uiState.activeTab === "employees");
  payslipModule.classList.toggle("module-active", uiState.activeTab === "payslip");
  balanceModule.classList.toggle("module-active", uiState.activeTab === "balance");
  contractsModule.classList.toggle("module-active", uiState.activeTab === "contracts");
  exportsModule.classList.toggle("module-active", uiState.activeTab === "exports");
  tabProposals.classList.toggle("tab-btn-active", uiState.activeTab === "proposals");
  tabClients.classList.toggle("tab-btn-active", uiState.activeTab === "clients");
  tabEmployees.classList.toggle("tab-btn-active", uiState.activeTab === "employees");
  tabPayslip.classList.toggle("tab-btn-active", uiState.activeTab === "payslip");
  tabBalance.classList.toggle("tab-btn-active", uiState.activeTab === "balance");
  tabContracts.classList.toggle("tab-btn-active", uiState.activeTab === "contracts");
  tabExports.classList.toggle("tab-btn-active", uiState.activeTab === "exports");

  btnExportProposal.style.display = uiState.activeTab === "proposals" ? "" : "none";
  btnExportPayslip.style.display = uiState.activeTab === "payslip" ? "" : "none";
  uiState.notificationsOpen = false;
  setModulesMenuOpen(false);
}

function setProposalStep(nextStep) {
  const step = Math.max(1, Math.min(uiState.maxProposalStep, Number(nextStep || 1)));
  uiState.proposalStep = step;

  const stepPanels = document.querySelectorAll(".proposal-step");
  const stepChips = document.querySelectorAll(".step-chip");
  const btnPrev = document.getElementById("btnPrevStep");
  const btnNext = document.getElementById("btnNextStep");

  stepPanels.forEach((panel) => {
    const panelStep = Number(panel.getAttribute("data-step"));
    panel.classList.toggle("proposal-step-active", panelStep === step);
  });

  stepChips.forEach((chip) => {
    const chipStep = Number(chip.getAttribute("data-step-jump"));
    chip.classList.toggle("step-chip-active", chipStep === step);
  });

  btnPrev.disabled = step === 1;
  btnNext.textContent = step === uiState.maxProposalStep ? "Última etapa" : "Próxima etapa";
}

function formToObject(form) {
  const data = new FormData(form);
  const obj = {};
  for (const [key, value] of data.entries()) obj[key] = String(value).trim();
  return obj;
}

function setFormValues(form, values) {
  Object.entries(values || {}).forEach(([key, value]) => {
    const element = form.elements.namedItem(key);
    if (element) element.value = value;
  });
}

function refreshBrazilianPatternInputs() {
  document.querySelectorAll("input[name]").forEach((input) => {
    applyBrazilianInputPattern(input, "input");
    applyBrazilianInputPattern(input, "blur");
  });
}

function renderDefaultFurnitureOptions() {
  const container = document.getElementById("defaultFurnitureOptions");
  if (!container) return;

  container.innerHTML = DEFAULT_FURNITURE.map(
    (entry, index) => {
      const variant = FURNITURE_VARIANTS[entry.item];
      const variantSelect = variant
        ? `
          <label class="furniture-option-qty-label">
            ${escapeHtml(variant.label)}
            <select class="default-furniture-variant" data-default-variant-index="${index}">
              ${variant.options.map((option) => `<option value="${escapeHtml(option)}">${escapeHtml(option)}</option>`).join("")}
            </select>
          </label>
        `
        : "";

      return `
      <div class="furniture-option-row">
        <label class="furniture-option-check">
          <input type="checkbox" class="default-furniture-checkbox" data-default-index="${index}" />
          <span>${escapeHtml(entry.item)}</span>
        </label>
        <div class="furniture-option-meta">
          <span class="furniture-option-environment">${escapeHtml(entry.environment)}</span>
          ${variantSelect}
          <label class="furniture-option-qty-label">
            Qtd
            <input
              type="number"
              min="1"
              value="1"
              class="default-furniture-qty"
              data-default-qty-index="${index}"
              aria-label="Quantidade de ${escapeHtml(entry.item)}"
            />
          </label>
        </div>
      </div>
    `;
    },
  ).join("");
}

function removeProposalPhotoById(photoId) {
  const idx = state.proposalPhotos.findIndex((photo) => photo.id === photoId);
  if (idx < 0) return;
  state.proposalPhotos.splice(idx, 1);
  saveState();
  renderAll();
}

function renderProposalPhotosList() {
  const container = document.getElementById("proposalPhotosList");
  if (!container) return;

  container.innerHTML = "";
  if (!state.proposalPhotos.length) {
    container.innerHTML = '<li><span class="small">Nenhuma foto anexada.</span></li>';
    return;
  }

  state.proposalPhotos.forEach((photo, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<span><strong>${index + 1}.</strong> ${escapeHtml(photo.name)}</span>`;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.className = "btn btn-danger";
    btn.textContent = "Remover";
    btn.addEventListener("click", () => removeProposalPhotoById(photo.id));
    li.appendChild(btn);
    container.appendChild(li);
  });
}

function upsertFurnitureItem(item, environment, quantity, notes = "") {
  const normalizedItem = canonicalFurnitureItemName(item);
  const normalizedEnv = String(environment || "").trim();
  const normalizedNotes = String(notes || "").trim();
  const qty = Number(quantity || 0);
  if (!normalizedItem || !normalizedEnv || qty <= 0) return;

  const existing = state.furniture.find(
    (x) => x.item === normalizedItem
      && x.environment === normalizedEnv
      && String(x.notes || "").trim() === normalizedNotes,
  );

  if (existing) {
    existing.quantity = Number(existing.quantity || 0) + qty;
    existing.notes = String(existing.notes || normalizedNotes).trim();
  } else {
    state.furniture.push({
      item: normalizedItem,
      environment: normalizedEnv,
      quantity: qty,
      notes: normalizedNotes,
    });
  }
}

function editFurnitureItem(item, environment, notes = "") {
  const target = state.furniture.find(
    (entry) =>
      entry.item === item
      && entry.environment === environment
      && String(entry.notes || "").trim() === String(notes || "").trim(),
  );
  if (!target) return;

  const currentQty = Number(target.quantity || 0);
  const qtyInput = prompt("Nova quantidade:", String(currentQty));
  if (qtyInput === null) return;
  const parsedQty = Number.parseInt(String(qtyInput || "").trim(), 10);
  if (!Number.isFinite(parsedQty) || parsedQty <= 0) {
    alert("Quantidade inválida. Informe um número inteiro maior que zero.");
    return;
  }

  const notesInput = prompt(
    "Observações (opcional):",
    String(target.notes || ""),
  );
  if (notesInput === null) return;

  target.quantity = parsedQty;
  target.notes = String(notesInput || "").trim();
  saveState();
  renderAll();
}

function renderFurnitureList() {
  const container = document.getElementById("furnitureList");
  if (!container) return;

  const sorted = getFurnitureSorted();
  container.innerHTML = "";
  if (!sorted.length) {
    container.innerHTML = '<li><span class="small">Nenhum item adicionado.</span></li>';
    return;
  }

  sorted.forEach((item) => {
    const li = document.createElement("li");
    const notesText = String(item.notes || "").trim();
    li.innerHTML = `
      <span>
        <strong>${escapeHtml(item.item)}</strong> (${escapeHtml(item.environment || "-")}) : ${escapeHtml(item.quantity)}
        ${notesText ? `<br /><small class="small">Obs.: ${escapeHtml(notesText)}</small>` : ""}
      </span>
    `;

    const actions = document.createElement("div");
    actions.className = "exports-actions";

    const btnEdit = document.createElement("button");
    btnEdit.type = "button";
    btnEdit.className = "btn";
    btnEdit.textContent = "Editar";
    btnEdit.addEventListener("click", () => {
      editFurnitureItem(item.item, item.environment, item.notes);
    });

    const btnRemove = document.createElement("button");
    btnRemove.type = "button";
    btnRemove.className = "btn btn-danger";
    btnRemove.textContent = "Remover";
    btnRemove.addEventListener("click", () => {
      const originalIndex = state.furniture.findIndex(
        (x) => x.item === item.item
          && x.environment === item.environment
          && String(x.notes || "").trim() === String(item.notes || "").trim(),
      );
      if (originalIndex >= 0) removeByIndex(state.furniture, originalIndex);
    });

    actions.appendChild(btnEdit);
    actions.appendChild(btnRemove);
    li.appendChild(actions);
    container.appendChild(li);
  });
}

function getFurnitureSorted() {
  const order = new Map(DEFAULT_FURNITURE.map((entry, index) => [entry.item, index]));
  const envOrder = new Map(ENVIRONMENT_ORDER.map((entry, index) => [entry, index]));
  return [...state.furniture].sort((a, b) => {
    const aEnv = a.environment || "Não informado";
    const bEnv = b.environment || "Não informado";
    const aEnvOrder = envOrder.has(aEnv) ? envOrder.get(aEnv) : 999;
    const bEnvOrder = envOrder.has(bEnv) ? envOrder.get(bEnv) : 999;
    if (aEnvOrder !== bEnvOrder) return aEnvOrder - bEnvOrder;

    const aOrder = order.has(a.item) ? order.get(a.item) : 999;
    const bOrder = order.has(b.item) ? order.get(b.item) : 999;
    if (aOrder !== bOrder) return aOrder - bOrder;
    return a.item.localeCompare(b.item, "pt-BR");
  });
}

function removeByIndex(list, index) {
  list.splice(index, 1);
  saveState();
  renderAll();
}

function renderList(container, list, labelFn, onRemove) {
  container.innerHTML = "";
  if (!list.length) {
    container.innerHTML = '<li><span class="small">Nenhum item adicionado.</span></li>';
    return;
  }

  list.forEach((item, index) => {
    const li = document.createElement("li");
    li.innerHTML = `<span>${labelFn(item)}</span>`;
    const btn = document.createElement("button");
    btn.type = "button";
    btn.textContent = "Remover";
    btn.addEventListener("click", () => onRemove(index));
    li.appendChild(btn);
    container.appendChild(li);
  });
}

function calculateTotal() {
  const capacity = Number(state.property.capacity || 0);
  const dailyRatePerPerson = Number(state.property.dailyRatePerPerson || 0);
  const dailyHostingTotal = capacity * dailyRatePerPerson;
  const monthlyValue = dailyHostingTotal * 30;

  const marginPercent = Number(state.pricing.marginPercent || 0);
  const adminFeePercent = Number(state.pricing.adminFeePercent || 0);
  const discountPercent = Number(state.pricing.discount || 0);

  const marginValue = monthlyValue * (marginPercent / 100);
  const adminFeeValue = monthlyValue * (adminFeePercent / 100);
  const subtotal = monthlyValue + marginValue + adminFeeValue;
  const discountValue = subtotal * (discountPercent / 100);

  return {
    capacity,
    dailyRatePerPerson,
    dailyHostingTotal,
    monthlyValue,
    marginPercent,
    marginValue,
    adminFeePercent,
    adminFeeValue,
    discountPercent,
    discountValue,
    final: Math.max(subtotal - discountValue, 0),
  };
}

function buildFullAddress(property) {
  if (property.address) return property.address;

  const line1 = [property.street, property.number].filter(Boolean).join(", ");
  const line2 = [property.complement, property.district].filter(Boolean).join(" - ");
  const line3 = [property.city, property.state].filter(Boolean).join(" / ");
  const line4 = property.zipCode || "";

  return [line1, line2, line3, line4].filter(Boolean).join(" | ");
}

function hasValue(value) {
  return String(value || "").trim().length > 0;
}

function renderProposal() {
  const output = document.getElementById("proposalOutput");
  const totals = calculateTotal();

  const propertyName = state.property.name || "Não informado";
  const fullAddress = buildFullAddress(state.property);

  const clientEntries = [
    { label: "Empresa", value: state.company.name },
    { label: "Destinatário", value: state.proposal.recipient },
    { label: "CNPJ", value: state.company.cnpj },
    { label: "Contato", value: state.company.contact },
    { label: "Celular", value: state.company.phone },
    { label: "E-mail", value: state.company.email },
    { label: "Cidade", value: state.company.city },
  ].filter((entry) => hasValue(entry.value));

  const clientRowsHtml = clientEntries.length
    ? clientEntries
        .map(
          (entry) => `<div><strong>${escapeHtml(entry.label)}:</strong> ${escapeHtml(entry.value)}</div>`,
        )
        .join("")
    : '<div class="small" style="grid-column: 1 / -1;">Nenhuma informação de cliente preenchida.</div>';

  const addressRowHtml = hasValue(fullAddress)
    ? `<div style="grid-column: 1 / -1;"><strong>Endereço:</strong> ${escapeHtml(fullAddress)}</div>`
    : "";
  const propertyDescriptionRow = hasValue(state.property.description)
    ? `<div style="grid-column: 1 / -1;"><strong>Descrição:</strong> ${escapeHtml(state.property.description)}</div>`
    : "";
  const proposalNotes = state.company.notes
    || "Condições sujeitas a ajustes conforme volume de unidades e prazo contratual.";

  const sortedFurniture = getFurnitureSorted();
  const furnitureRows = sortedFurniture.length
    ? sortedFurniture
        .map((item, index, arr) => {
          const environment = item.environment || "Não informado";
          const previousEnvironment = index > 0 ? arr[index - 1].environment || "Não informado" : "";
          const environmentHeader =
            environment !== previousEnvironment
              ? `<tr><td colspan="4"><strong>${escapeHtml(environment)}</strong></td></tr>`
              : "";
          return `${environmentHeader}<tr><td>${escapeHtml(item.item)}</td><td>${escapeHtml(environment)}</td><td>${escapeHtml(item.quantity)}</td><td>${escapeHtml(item.notes || "-")}</td></tr>`;
        })
        .join("")
    : '<tr><td colspan="4">Não informado</td></tr>';

  const photoPages = [];
  for (let i = 0; i < state.proposalPhotos.length; i += 8) {
    photoPages.push(state.proposalPhotos.slice(i, i + 8));
  }
  const photosSectionHtml = photoPages.length
    ? `
      <section class="doc-section doc-photos-section">
        <h4>8. Anexos Fotográficos do Imóvel</h4>
        ${photoPages
          .map(
            (page) => `
              <div class="doc-photos-page">
                <div class="doc-photos-grid">
                  ${page
                    .map(
                      (photo, index) => `
                        <figure class="doc-photo-item">
                          <img src="${photo.dataUrl}" alt="Foto do imóvel ${index + 1}" />
                          <figcaption class="small">${escapeHtml(photo.name || "Foto do imóvel")}</figcaption>
                        </figure>
                      `,
                    )
                    .join("")}
                </div>
              </div>
            `,
          )
          .join("")}
      </section>
    `
    : "";

  output.innerHTML = `
    <article class="proposal-doc">
      <header class="doc-header">
        <div class="doc-brand">
          <img class="doc-logo" src="${FIXED_LOGO_PATH}" alt="Logo Vila Marques Alojamentos" />
          <div class="doc-title">
            <h3>Proposta Comercial</h3>
            <p>Alojamentos corporativos</p>
          </div>
        </div>
        <div class="doc-meta">
          <div><strong>Nº:</strong> ${escapeHtml(state.proposal.proposalNumber || "-")}</div>
          <div><strong>Emissão:</strong> ${formatDateBR(state.proposal.issueDate)}</div>
          <div><strong>Validade:</strong> ${formatDateBR(state.pricing.validUntil)}</div>
        </div>
      </header>

      <section class="doc-section">
        <h4>1. Dados do Cliente</h4>
        <div class="doc-grid">${clientRowsHtml}</div>
      </section>

      <section class="doc-section">
        <h4>2. Imóvel Ofertado</h4>
        <div class="doc-grid">
          <div><strong>Nome:</strong> ${escapeHtml(propertyName)}</div>
          <div><strong>Tipo:</strong> ${escapeHtml(state.property.type || "-")}</div>
          <div><strong>Classificação:</strong> ${escapeHtml(state.property.operationType || "-")}</div>
          <div><strong>Capacidade:</strong> ${escapeHtml(state.property.capacity || "-")} pessoa(s)</div>
          <div><strong>Quartos:</strong> ${escapeHtml(state.property.bedrooms || "-")}</div>
          <div><strong>Banheiros:</strong> ${escapeHtml(state.property.bathrooms || "-")}</div>
          <div><strong>Garagem:</strong> ${escapeHtml(state.property.garageSpots || "-")}</div>
          <div><strong>Área de serviço:</strong> ${escapeHtml(state.property.serviceAreaType || "-")}</div>
          <div><strong>Diária por pessoa:</strong> ${currencyBRL.format(Number(state.property.dailyRatePerPerson || 0))}</div>
          <div><strong>Total diária do imóvel:</strong> ${currencyBRL.format(totals.dailyHostingTotal)}</div>
          ${addressRowHtml}
          ${propertyDescriptionRow}
        </div>
      </section>

      <section class="doc-section">
        <h4>3. Mobília Inclusa</h4>
        <table class="doc-table">
          <thead>
            <tr><th>Item</th><th>Ambiente</th><th>Quantidade</th><th>Observações</th></tr>
          </thead>
          <tbody>${furnitureRows}</tbody>
        </table>
      </section>

      <section class="doc-section">
        <h4>4. Itens, Estrutura e Serviços Inclusos</h4>
        <ul class="doc-numbered-list">
          <li><strong>4.1</strong> Internet instalada;</li>
          <li><strong>4.2</strong> Utensílios para limpeza;</li>
          <li><strong>4.3</strong> Faxina 05 vezes por semana (segunda a sexta-feira);</li>
          <li><strong>4.4</strong> Lavagem de uniformes 03 vezes por semana;</li>
          <li><strong>4.5</strong> Troca e lavagem de roupas de cama 01 vez por semana;</li>
          <li><strong>4.6</strong> Manutenção elétrica e hidráulica (exceto vandalismo);</li>
          <li><strong>4.7</strong> Atendimento às NR's exigidas pela VALE / SAMARCO.</li>
        </ul>
      </section>

      <section class="doc-section doc-section-narrow">
        <h4>5. Condição Comercial</h4>
        <div class="doc-totals">
          <div class="doc-row"><span>Base diária (${totals.capacity} pessoa(s) x ${currencyBRL.format(totals.dailyRatePerPerson)})</span><strong>${currencyBRL.format(totals.dailyHostingTotal)}</strong></div>
          <div class="doc-row"><span>Valor mensal (diária x 30)</span><strong>${currencyBRL.format(totals.monthlyValue)}</strong></div>
          <div class="doc-row"><span>Margem comercial (${totals.marginPercent}%)</span><strong>${currencyBRL.format(totals.marginValue)}</strong></div>
          <div class="doc-row"><span>Taxa administrativa (${totals.adminFeePercent}%)</span><strong>${currencyBRL.format(totals.adminFeeValue)}</strong></div>
          <div class="doc-row"><span>Desconto (${totals.discountPercent}%)</span><strong>- ${currencyBRL.format(totals.discountValue)}</strong></div>
          <div class="doc-row doc-highlight"><span>Valor final da proposta</span><span>${currencyBRL.format(totals.final)}</span></div>
        </div>
      </section>

      <section class="doc-section doc-section-narrow doc-avoid-break">
        <h4>6. Vigência e Pagamento</h4>
        <div class="doc-grid">
          <div><strong>Vigência inicial:</strong> ${formatDateBR(state.proposal.contractStartDate)}</div>
          <div><strong>Vigência final:</strong> ${formatDateBR(state.proposal.contractEndDate)}</div>
          <div><strong>Dia de pagamento:</strong> ${escapeHtml(state.proposal.paymentDay || "-")}</div>
          <div style="grid-column: 1 / -1;">
            <strong>Condição de pagamento:</strong>
            Pagamento feito no dia ${escapeHtml(state.proposal.paymentDay || "-")} de cada mês durante todo o período de vigência do contrato, por meio de transferência PIX ou depósito bancário para a conta fornecida pela contratada.
          </div>
        </div>
      </section>

      <section class="doc-section doc-section-narrow doc-avoid-break">
        <h4>7. Responsabilidades Contratuais</h4>
        <p>
          Ficam sob responsabilidade do contratado todos os encargos referentes a aluguel, IPTU, água, energia
          elétrica, internet, manutenção estrutural e operacional do alojamento. Casos de danos decorrentes de
          vandalismo serão de responsabilidade do contratante.
        </p>
      </section>

      ${photosSectionHtml}

      <footer class="doc-footer doc-avoid-break">
        <p><strong>Contratado:</strong> ${escapeHtml(CONTRACTOR_INFO.companyName)}</p>
        <p><strong>CNPJ:</strong> ${escapeHtml(CONTRACTOR_INFO.cnpj)}</p>
        <p><strong>Responsável:</strong> ${escapeHtml(CONTRACTOR_INFO.responsible)} | <strong>Telefone:</strong> ${escapeHtml(CONTRACTOR_INFO.phone)}</p>
        <p><strong>Observações:</strong> ${escapeHtml(proposalNotes)}</p>
      </footer>
    </article>
  `;
}

function calculatePayslipTotals() {
  const baseSalary = Number(state.payslip.baseSalary || 0);
  const monthTotalDays = Math.max(1, Number(state.payslip.monthTotalDays || 30));
  const businessDaysInMonth = Math.max(0, Number(state.payslip.businessDaysInMonth || 0));
  const absenceDays = Math.max(0, Number(state.payslip.absenceDays || 0));
  const allowanceDays = Math.max(0, Number(state.payslip.allowanceDays || 0));
  const cappedAbsenceDays = Math.min(absenceDays, businessDaysInMonth);
  const cappedAllowanceDays = Math.min(allowanceDays, cappedAbsenceDays);
  const unexcusedAbsenceDays = Math.max(0, cappedAbsenceDays - cappedAllowanceDays);
  const salaryPaidDays = Math.max(0, businessDaysInMonth - unexcusedAbsenceDays);
  const workedBusinessDays = Math.max(0, businessDaysInMonth - cappedAbsenceDays);
  const vaNotPaidDaysTotal = cappedAbsenceDays;
  const vaNotPaidDaysAboned = cappedAllowanceDays;
  const vaNotPaidDaysUnexcused = unexcusedAbsenceDays;
  const baseDailyValue = baseSalary / monthTotalDays;
  const absenceSalaryDiscountValue = baseDailyValue * unexcusedAbsenceDays;
  const salaryAfterAbsence = baseSalary - absenceSalaryDiscountValue;
  const mealAllowanceFixed = Number(state.payslip.mealAllowanceFixed || 0);
  const mealAllowanceDaily = Number(state.payslip.mealAllowanceDaily || 0);
  const fixedDiscountPercent = Number(state.payslip.fixedDiscountPercent || 0);
  const maximumMealAllowanceDays = businessDaysInMonth;
  const mealAllowancePaidDays = workedBusinessDays;
  const mealAllowanceDailyTotal = mealAllowanceDaily * mealAllowancePaidDays;
  const mealAllowanceTotal = mealAllowanceFixed + mealAllowanceDailyTotal;
  const mealAllowanceCardDiscountPercent = 20;
  const mealAllowanceCardDiscountValue = mealAllowanceTotal * (mealAllowanceCardDiscountPercent / 100);
  const customEarningsTotal = state.payslip.earnings.reduce((sum, item) => sum + Number(item.value || 0), 0);
  const customDiscountsTotal = state.payslip.discounts.reduce((sum, item) => sum + Number(item.value || 0), 0);
  const fixedDiscountValue = salaryAfterAbsence * (fixedDiscountPercent / 100);
  const earningsTotal = baseSalary + mealAllowanceFixed + mealAllowanceDailyTotal + customEarningsTotal;
  const discountsTotal =
    customDiscountsTotal
    + fixedDiscountValue
    + mealAllowanceCardDiscountValue
    + absenceSalaryDiscountValue;
  const netCashValue =
    baseSalary
    + customEarningsTotal
    - customDiscountsTotal
    - fixedDiscountValue
    - mealAllowanceCardDiscountValue;
  const netCashAfterAbsence = netCashValue - absenceSalaryDiscountValue;
  const totalReceivedValue = netCashAfterAbsence + mealAllowanceTotal;

  return {
    businessDaysInMonth,
    monthTotalDays,
    absenceDays: cappedAbsenceDays,
    allowanceDays: cappedAllowanceDays,
    unexcusedAbsenceDays,
    salaryPaidDays,
    workedBusinessDays,
    vaNotPaidDaysTotal,
    vaNotPaidDaysAboned,
    vaNotPaidDaysUnexcused,
    baseDailyValue,
    absenceSalaryDiscountValue,
    salaryAfterAbsence,
    mealAllowanceFixed,
    mealAllowanceDaily,
    mealAllowancePaidDays,
    maximumMealAllowanceDays,
    mealAllowanceDailyTotal,
    mealAllowanceTotal,
    mealAllowanceCardDiscountPercent,
    mealAllowanceCardDiscountValue,
    fixedDiscountPercent,
    fixedDiscountValue,
    customEarningsTotal,
    customDiscountsTotal,
    earningsTotal,
    discountsTotal,
    netCashValue: netCashAfterAbsence,
    totalReceivedValue,
  };
}

function renderPayslipCopy(copyLabel) {
  const totals = calculatePayslipTotals();

  const earningsRows = [
    `<tr><td>Salário base bruto (mensal fixo)</td><td>${currencyBRL.format(
      Number(state.payslip.baseSalary || 0),
    )}</td></tr>`,
    totals.mealAllowanceFixed > 0
      ? `<tr><td>Vale alimentação fixo</td><td>${currencyBRL.format(totals.mealAllowanceFixed)}</td></tr>`
      : "",
    totals.mealAllowanceDaily > 0
      ? `<tr><td>Vale alimentação diário (${totals.mealAllowancePaidDays} dia(s) úteis trabalhados)</td><td>${currencyBRL.format(totals.mealAllowanceDailyTotal)}</td></tr>`
      : "",
    ...state.payslip.earnings.map(
      (item) =>
        `<tr><td>${escapeHtml(item.description)}</td><td>${currencyBRL.format(
          Number(item.value || 0),
        )}</td></tr>`,
    ),
  ].join("");

  const discountItems = [];
  if (totals.absenceSalaryDiscountValue > 0) {
    discountItems.push(
      `<tr><td>Desconto por falta não abonada (${totals.unexcusedAbsenceDays} dia(s))</td><td>${currencyBRL.format(totals.absenceSalaryDiscountValue)}</td></tr>`,
    );
  }
  if (totals.mealAllowanceTotal > 0) {
    discountItems.push(
      `<tr><td>Coparticipação VA (${totals.mealAllowanceCardDiscountPercent}% sobre ${currencyBRL.format(totals.mealAllowanceTotal)})</td><td>${currencyBRL.format(totals.mealAllowanceCardDiscountValue)}</td></tr>`,
    );
  }
  if (totals.fixedDiscountPercent > 0) {
    discountItems.push(
      `<tr><td>Desconto fixo (${totals.fixedDiscountPercent}%)</td><td>${currencyBRL.format(totals.fixedDiscountValue)}</td></tr>`,
    );
  }
  state.payslip.discounts.forEach((item) => {
    discountItems.push(
      `<tr><td>${escapeHtml(item.description)}</td><td>${currencyBRL.format(Number(item.value || 0))}</td></tr>`,
    );
  });
  const discountRows = discountItems.join("") || "<tr><td>-</td><td>R$ 0,00</td></tr>";

  return `
    <article class="payslip-copy">
      <div class="payslip-header">
        <div class="payslip-brand">
          <img class="payslip-logo" src="${FIXED_LOGO_PATH}" alt="Logo Vila Marques" />
          <div>
            <div class="payslip-title">CONTRA-CHEQUE</div>
            <div class="small">${escapeHtml(CONTRACTOR_INFO.companyName)} | CNPJ ${escapeHtml(CONTRACTOR_INFO.cnpj)}</div>
          </div>
        </div>
        <div class="payslip-meta">
          <div><strong>Via:</strong> ${escapeHtml(copyLabel)}</div>
          <div><strong>Competência:</strong> ${escapeHtml(state.payslip.competence || "-")}</div>
          <div><strong>Pagamento:</strong> ${formatDateBR(state.payslip.paymentDate)}</div>
          <div><strong>Forma:</strong> ${escapeHtml(state.payslip.paymentMethod || "-")}</div>
        </div>
      </div>

      <div class="payslip-info">
        <div><strong>Funcionário:</strong> ${escapeHtml(state.payslip.employeeName || "-")}</div>
        <div><strong>CPF:</strong> ${escapeHtml(state.payslip.employeeCpf || "-")}</div>
        <div><strong>Cargo:</strong> ${escapeHtml(state.payslip.position || "-")}</div>
        <div><strong>Matrícula:</strong> ${escapeHtml(state.payslip.registration || "-")}</div>
        <div><strong>Salário base bruto:</strong> ${currencyBRL.format(Number(state.payslip.baseSalary || 0))}</div>
        <div><strong>Dias totais do mês (cálculo do salário/dia):</strong> ${escapeHtml(String(totals.monthTotalDays))} | <strong>Valor do dia:</strong> ${currencyBRL.format(totals.baseDailyValue)}</div>
        <div><strong>Dias úteis do mês:</strong> ${escapeHtml(String(totals.businessDaysInMonth))} | <strong>Faltas:</strong> ${escapeHtml(String(totals.absenceDays))} | <strong>Abonos:</strong> ${escapeHtml(String(totals.allowanceDays))}</div>
        <div><strong>Dias pagos de salário:</strong> ${escapeHtml(String(totals.salaryPaidDays))} | <strong>Faltas não abonadas:</strong> ${escapeHtml(String(totals.unexcusedAbsenceDays))}</div>
        <div><strong>Dias pagos de VA:</strong> ${escapeHtml(String(totals.mealAllowancePaidDays))} | <strong>Dias sem VA:</strong> ${escapeHtml(String(totals.vaNotPaidDaysTotal))} (abonados: ${escapeHtml(String(totals.vaNotPaidDaysAboned))}, não abonados: ${escapeHtml(String(totals.vaNotPaidDaysUnexcused))})</div>
        <div><strong>Regra:</strong> salário base mensal fixo (independente de 28/30/31 dias); abono mantém o salário do dia, mas o dia abonado NÃO gera VA.</div>
        <div><strong>Regra do VA:</strong> recebido integralmente no cartão e coparticipação de 20% descontada no pagamento líquido em mãos.</div>
      </div>

      <table class="payslip-table">
        <thead>
          <tr><th>Descrição</th><th>Valor (R$)</th></tr>
        </thead>
        <tbody>${earningsRows}</tbody>
      </table>

      <table class="payslip-table">
        <thead>
          <tr><th>Descrição</th><th>Valor (R$)</th></tr>
        </thead>
        <tbody>${discountRows}</tbody>
      </table>

      <table class="payslip-table">
        <tbody>
          <tr><td><strong>Total de Proventos</strong></td><td><strong>${currencyBRL.format(totals.earningsTotal)}</strong></td></tr>
          <tr><td><strong>Total de Descontos</strong></td><td><strong>${currencyBRL.format(totals.discountsTotal)}</strong></td></tr>
          <tr><td><strong>Salário líquido</strong></td><td><strong>${currencyBRL.format(totals.netCashValue)}</strong></td></tr>
          <tr><td><strong>Crédito VA no cartão</strong></td><td><strong>${currencyBRL.format(totals.mealAllowanceTotal)}</strong></td></tr>
          <tr><td><strong>Total recebido (mãos + cartão)</strong></td><td><strong>${currencyBRL.format(totals.totalReceivedValue)}</strong></td></tr>
        </tbody>
      </table>

      <div class="payslip-sign">
        <div class="sign-box">Assinatura do Empregador</div>
        <div class="sign-box">Assinatura do Funcionário</div>
      </div>
    </article>
  `;
}

function renderPayslip() {
  const output = document.getElementById("payslipOutput");
  if (!output) return;

  output.innerHTML = `
    <section class="payslip-sheet">
      ${renderPayslipCopy("Empresa")}
      ${renderPayslipCopy("Funcionário")}
    </section>
  `;
}

function toMonthKey(dateTimeStr) {
  const dt = new Date(dateTimeStr);
  if (Number.isNaN(dt.getTime())) return "Sem data";
  const y = dt.getFullYear();
  const m = String(dt.getMonth() + 1).padStart(2, "0");
  return `${y}-${m}`;
}

function monthLabel(monthKey) {
  if (monthKey === "Sem data") return monthKey;
  const [year, month] = monthKey.split("-");
  const dt = new Date(Number(year), Number(month) - 1, 1);
  return dt.toLocaleDateString("pt-BR", { month: "long", year: "numeric" });
}

function monthNameByNumber(monthNumber) {
  return new Date(2000, monthNumber - 1, 1).toLocaleDateString("pt-BR", { month: "long" });
}

function formatDateTimeBR(value) {
  const dt = new Date(value);
  if (Number.isNaN(dt.getTime())) return value;
  return dt.toLocaleString("pt-BR");
}

function isFuelExpense(entry) {
  if (!entry || entry.type !== "expense") return false;
  const text = String(entry.description || "").toLowerCase();
  const fuelKeywords = [
    "combustivel",
    "combustível",
    "gasolina",
    "diesel",
    "etanol",
    "alcool",
    "álcool",
    "abastecimento",
    "gnv",
  ];
  return fuelKeywords.some((keyword) => text.includes(keyword));
}

function isTollExpense(entry) {
  if (!entry || entry.type !== "expense") return false;
  const text = String(entry.description || "").toLowerCase();
  const tollKeywords = ["pedagio", "pedágio", "sem parar", "conectcar", "tag pedagio"];
  return tollKeywords.some((keyword) => text.includes(keyword));
}

function removeBalanceEntryById(id) {
  const index = state.balance.entries.findIndex((entry) => entry.id === id);
  if (index >= 0) {
    state.balance.entries.splice(index, 1);
    saveState();
    renderBalance();
  }
}

function renderBalance() {
  const summaryContainer = document.getElementById("balanceSummary");
  const contractSummaryContainer = document.getElementById("balanceContractSummary");
  const byResponsibleContainer = document.getElementById("balanceByResponsible");
  const monthlyContainer = document.getElementById("balanceMonthly");
  const yearSelect = document.getElementById("balanceYearSelect");
  const monthSelect = document.getElementById("balanceMonthSelect");
  const contractSelect = document.getElementById("balanceContractSelect");
  const expenseContractSelect = document.getElementById("expenseContractSelect");
  const monthFilter = document.getElementById("balanceMonthFilter");
  const btnMonthly = document.getElementById("btnBalanceMonthly");
  const btnYearly = document.getElementById("btnBalanceYearly");
  if (!summaryContainer || !contractSummaryContainer || !byResponsibleContainer || !monthlyContainer) return;

  const entries = [...state.balance.entries].sort(
    (a, b) => new Date(b.dateTime).getTime() - new Date(a.dateTime).getTime(),
  );

  const years = Array.from(
    new Set(
      entries
        .map((entry) => new Date(entry.dateTime).getFullYear())
        .filter((year) => Number.isFinite(year)),
    ),
  ).sort((a, b) => b - a);

  if (!years.length) years.push(new Date().getFullYear());
  if (!years.includes(uiState.balanceYear)) uiState.balanceYear = years[0];

  yearSelect.innerHTML = years
    .map((year) => `<option value="${year}">${year}</option>`)
    .join("");
  yearSelect.value = String(uiState.balanceYear);
  monthSelect.value = String(uiState.balanceMonth);
  const contractsForBalance = [...(state.contractsPortfolio || [])]
    .filter((item) => hasContractContent(item))
    .sort((a, b) => String(a.contractName || "").localeCompare(String(b.contractName || ""), "pt-BR"));
  const contractOptions = contractsForBalance
    .map((item) => `<option value="${escapeHtml(item.id)}">${escapeHtml(item.contractName || "Sem nome")}</option>`)
    .join("");
  if (contractSelect) {
    contractSelect.innerHTML = `<option value="">Geral (todos)</option>${contractOptions}`;
    const activeBalanceContractId = String(uiState.balanceContractId || "");
    const contractExists = contractsForBalance.some((item) => item.id === activeBalanceContractId);
    if (!contractExists) uiState.balanceContractId = "";
    contractSelect.value = String(uiState.balanceContractId || "");
  }
  if (expenseContractSelect) {
    expenseContractSelect.innerHTML = `<option value="">Sem contrato (geral)</option>${contractOptions}`;
  }

  btnMonthly.classList.toggle("btn-primary", uiState.balanceMode === "monthly");
  btnYearly.classList.toggle("btn-primary", uiState.balanceMode === "yearly");
  monthFilter.style.display = uiState.balanceMode === "monthly" ? "" : "none";

  const entriesInYear = entries.filter(
    (entry) => new Date(entry.dateTime).getFullYear() === uiState.balanceYear,
  );

  const scopedEntries =
    uiState.balanceMode === "monthly"
      ? entriesInYear.filter(
          (entry) => new Date(entry.dateTime).getMonth() + 1 === uiState.balanceMonth,
        )
      : entriesInYear;

  const totalIncome = scopedEntries
    .filter((entry) => entry.type === "income")
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const totalExpense = scopedEntries
    .filter((entry) => entry.type === "expense")
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const totalFuelExpense = scopedEntries
    .filter((entry) => isFuelExpense(entry))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const totalTollExpense = scopedEntries
    .filter((entry) => isTollExpense(entry))
    .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
  const totalProfit = totalIncome - totalExpense;

  const summaryTitle =
    uiState.balanceMode === "monthly"
      ? `${monthNameByNumber(uiState.balanceMonth)} de ${uiState.balanceYear}`
      : `Ano de ${uiState.balanceYear}`;

  const contractScopedEntries = uiState.balanceContractId
    ? scopedEntries.filter((entry) => String(entry.contractId || "") === uiState.balanceContractId)
    : [];

  const expensesByResponsible = scopedEntries
    .filter((entry) => entry.type === "expense")
    .reduce((acc, entry) => {
      const key = String(entry.responsible || "Não informado").trim() || "Não informado";
      acc[key] = (acc[key] || 0) + Number(entry.amount || 0);
      return acc;
    }, {});

  const expensesByResponsibleRows = Object.entries(expensesByResponsible)
    .sort((a, b) => b[1] - a[1])
    .map(
      ([responsible, amount]) => `
        <tr>
          <td>${escapeHtml(responsible)}</td>
          <td class="balance-expense">${currencyBRL.format(amount)}</td>
        </tr>
      `,
    )
    .join("");

  summaryContainer.innerHTML = `
    <div class="small">Resumo de ${escapeHtml(summaryTitle)}</div>
    <div class="balance-summary-grid">
      <div class="balance-summary-card"><div class="label">Entradas Totais</div><div class="value balance-income">${currencyBRL.format(totalIncome)}</div></div>
      <div class="balance-summary-card"><div class="label">Despesas Totais</div><div class="value balance-expense">${currencyBRL.format(totalExpense)}</div></div>
      <div class="balance-summary-card"><div class="label">Combustível</div><div class="value balance-expense">${currencyBRL.format(totalFuelExpense)}</div></div>
      <div class="balance-summary-card"><div class="label">Pedágios</div><div class="value balance-expense">${currencyBRL.format(totalTollExpense)}</div></div>
      <div class="balance-summary-card"><div class="label">Lucro</div><div class="value">${currencyBRL.format(totalProfit)}</div></div>
    </div>
  `;

  byResponsibleContainer.innerHTML = expensesByResponsibleRows
    ? `
      <article class="yearly-overview">
        <h4>Comparativo de Gastos por Responsável (${escapeHtml(summaryTitle)})</h4>
        <table class="balance-table">
          <thead>
            <tr>
              <th>Responsável</th>
              <th>Total de despesas</th>
            </tr>
          </thead>
          <tbody>${expensesByResponsibleRows}</tbody>
        </table>
      </article>
    `
    : '<div class="small">Sem despesas no período para comparar responsáveis.</div>';

  if (!uiState.balanceContractId) {
    contractSummaryContainer.innerHTML = '<div class="small">Selecione um contrato no dropdown para ver o balanço específico dele.</div>';
  } else if (!contractScopedEntries.length) {
    contractSummaryContainer.innerHTML = `<div class="small">Sem lançamentos para o contrato "${escapeHtml(getContractDisplayName(uiState.balanceContractId))}" neste período.</div>`;
  } else {
    const contractIncome = contractScopedEntries
      .filter((entry) => entry.type === "income")
      .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const contractExpense = contractScopedEntries
      .filter((entry) => entry.type === "expense")
      .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const contractFuel = contractScopedEntries
      .filter((entry) => isFuelExpense(entry))
      .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const contractToll = contractScopedEntries
      .filter((entry) => isTollExpense(entry))
      .reduce((sum, entry) => sum + Number(entry.amount || 0), 0);
    const contractProfit = contractIncome - contractExpense;
    const contractRows = contractScopedEntries
      .map((entry) => {
        const typeLabel = entry.type === "income" ? "Entrada" : "Despesa";
        const typeClass = entry.type === "income" ? "balance-income" : "balance-expense";
        return `
          <tr>
            <td>${typeLabel}</td>
            <td>${escapeHtml(entry.description)}</td>
            <td>${formatDateTimeBR(entry.dateTime)}</td>
            <td>${escapeHtml(entry.responsible || "-")}</td>
            <td class="${typeClass}">${currencyBRL.format(Number(entry.amount || 0))}</td>
          </tr>
        `;
      })
      .join("");

    contractSummaryContainer.innerHTML = `
      <article class="yearly-overview">
        <h4>Balanço do Contrato: ${escapeHtml(getContractDisplayName(uiState.balanceContractId))}</h4>
        <div class="balance-summary-grid" style="padding: 10px;">
          <div class="balance-summary-card"><div class="label">Entradas</div><div class="value balance-income">${currencyBRL.format(contractIncome)}</div></div>
          <div class="balance-summary-card"><div class="label">Despesas</div><div class="value balance-expense">${currencyBRL.format(contractExpense)}</div></div>
          <div class="balance-summary-card"><div class="label">Combustível</div><div class="value balance-expense">${currencyBRL.format(contractFuel)}</div></div>
          <div class="balance-summary-card"><div class="label">Pedágios</div><div class="value balance-expense">${currencyBRL.format(contractToll)}</div></div>
          <div class="balance-summary-card"><div class="label">Lucro</div><div class="value">${currencyBRL.format(contractProfit)}</div></div>
        </div>
        <table class="balance-table">
          <thead>
            <tr>
              <th>Tipo</th>
              <th>Descrição</th>
              <th>Dia e horário</th>
              <th>Responsável</th>
              <th>Valor</th>
            </tr>
          </thead>
          <tbody>${contractRows}</tbody>
        </table>
      </article>
    `;
  }

  if (!scopedEntries.length) {
    monthlyContainer.innerHTML = '<div class="small">Nenhum lançamento cadastrado ainda.</div>';
    return;
  }

  if (uiState.balanceMode === "monthly") {
    const rows = scopedEntries
        .map((entry) => {
          const typeLabel = entry.type === "income" ? "Entrada" : "Despesa";
          const typeClass = entry.type === "income" ? "balance-income" : "balance-expense";
          const fuelTag = isFuelExpense(entry) ? '<span class="small"> (Combustível)</span>' : "";
          const tollTag = isTollExpense(entry) ? '<span class="small"> (Pedágio)</span>' : "";
          const responsible = entry.type === "expense" ? escapeHtml(entry.responsible || "-") : "-";
          return `
            <tr>
              <td>${typeLabel}</td>
              <td>${escapeHtml(entry.description)}${fuelTag}${tollTag}</td>
              <td>${formatDateTimeBR(entry.dateTime)}</td>
              <td>${escapeHtml(getContractDisplayName(entry.contractId))}</td>
              <td>${responsible}</td>
              <td class="${typeClass}">${currencyBRL.format(entry.amount)}</td>
              <td><button type="button" class="btn btn-danger btn-remove-balance" data-balance-id="${escapeHtml(entry.id)}">Remover</button></td>
            </tr>
          `;
        })
        .join("");

    monthlyContainer.innerHTML = `
        <article class="month-card">
          <div class="month-header">
            <div class="month-title">${escapeHtml(summaryTitle)}</div>
            <div class="month-profit">Lucro do mês: ${currencyBRL.format(totalProfit)}</div>
          </div>
          <table class="balance-table">
            <thead>
              <tr>
                <th>Tipo</th>
                <th>Descrição</th>
                <th>Dia e horário</th>
                <th>Contrato</th>
                <th>Responsável</th>
                <th>Valor</th>
                <th>Ações</th>
              </tr>
            </thead>
            <tbody>${rows}</tbody>
          </table>
        </article>
      `;
  } else {
    const monthBuckets = Array.from({ length: 12 }, (_, i) => i + 1).map((month) => {
      const monthEntries = entriesInYear.filter(
        (entry) => new Date(entry.dateTime).getMonth() + 1 === month,
      );
      const income = monthEntries
        .filter((entry) => entry.type === "income")
        .reduce((sum, entry) => sum + entry.amount, 0);
      const expense = monthEntries
        .filter((entry) => entry.type === "expense")
        .reduce((sum, entry) => sum + entry.amount, 0);
      const fuelExpense = monthEntries
        .filter((entry) => isFuelExpense(entry))
        .reduce((sum, entry) => sum + entry.amount, 0);
      const tollExpense = monthEntries
        .filter((entry) => isTollExpense(entry))
        .reduce((sum, entry) => sum + entry.amount, 0);
      return {
        month,
        income,
        expense,
        fuelExpense,
        tollExpense,
        profit: income - expense,
      };
    });

    const yearlyRows = monthBuckets
      .map(
        (bucket) => `
          <tr>
            <td>${monthNameByNumber(bucket.month)}</td>
            <td class="balance-income">${currencyBRL.format(bucket.income)}</td>
            <td class="balance-expense">${currencyBRL.format(bucket.expense)}</td>
            <td class="balance-expense">${currencyBRL.format(bucket.fuelExpense)}</td>
            <td class="balance-expense">${currencyBRL.format(bucket.tollExpense)}</td>
            <td>${currencyBRL.format(bucket.profit)}</td>
          </tr>
        `,
      )
      .join("");

    monthlyContainer.innerHTML = `
      <article class="yearly-overview">
        <h4>Panorama Anual ${uiState.balanceYear}</h4>
        <table class="balance-table">
          <thead>
            <tr>
              <th>Mês</th>
              <th>Entradas</th>
              <th>Despesas</th>
              <th>Combustível</th>
              <th>Pedágios</th>
              <th>Lucro</th>
            </tr>
          </thead>
          <tbody>${yearlyRows}</tbody>
        </table>
      </article>
    `;
  }

  document.querySelectorAll(".btn-remove-balance").forEach((button) => {
    button.addEventListener("click", () => {
      removeBalanceEntryById(button.getAttribute("data-balance-id"));
    });
  });
}

function renderSavedPayslipEmployees() {
  const select = document.getElementById("savedPayslipEmployeeSelect");
  if (!select) return;

  const options = (state.payslipEmployees || [])
    .map((employee) => {
      const label = `${employee.employeeName}${employee.employeeCpf ? ` - ${employee.employeeCpf}` : ""}${employee.position ? ` (${employee.position})` : ""}`;
      return `<option value="${escapeHtml(employee.id)}">${escapeHtml(label)}</option>`;
    })
    .join("");

  select.innerHTML = `<option value="">Selecionar funcionário salvo</option>${options}`;
  select.value = String(state.payslip.selectedEmployeeId || "");
}

function loadSavedPayslipEmployee(employeeId) {
  const employee = state.payslipEmployees.find((item) => item.id === employeeId);
  if (!employee) return;
  state.payslip = {
    ...state.payslip,
    selectedEmployeeId: employee.id,
    employeeName: employee.employeeName,
    employeeCpf: employee.employeeCpf,
    position: employee.position,
    registration: employee.registration,
    baseSalary: employee.baseSalary,
    mealAllowanceFixed: String(Number(employee.mealAllowanceFixed || 0)),
    mealAllowanceDaily: String(Number(employee.mealAllowanceDaily || 0)),
    fixedDiscountPercent: String(Number(employee.fixedDiscountPercent || 0)),
  };
  saveState();
  renderAll();
}

function resetEmployeeCatalogForm() {
  const form = document.getElementById("employeeCatalogForm");
  if (!form) return;
  form.reset();
  uiState.editingEmployeeId = "";
  uiState.pendingEmployeeDocuments = [];
  const cpfInput = form.elements.namedItem("employeeCpf");
  if (cpfInput) cpfInput.value = "";
  form.querySelectorAll("input[data-brl]").forEach((input) => {
    input.value = "R$ 0,00";
  });
  const fixedDiscountInput = form.elements.namedItem("fixedDiscountPercent");
  if (fixedDiscountInput) fixedDiscountInput.value = "0";
  const docsInput = document.getElementById("employeeDocsInput");
  if (docsInput) docsInput.value = "";
  renderPendingEmployeeDocuments();
}

function setEmployeeCatalogForm(employee) {
  const form = document.getElementById("employeeCatalogForm");
  if (!form || !employee) return;
  uiState.editingEmployeeId = String(employee.id || "");
  setFormValues(form, {
    employeeName: employee.employeeName || "",
    employeeCpf: employee.employeeCpf || "",
    position: employee.position || "",
    registration: employee.registration || "",
    baseSalary: formatBRLInputValue(employee.baseSalary || 0),
    mealAllowanceFixed: formatBRLInputValue(employee.mealAllowanceFixed || 0),
    mealAllowanceDaily: formatBRLInputValue(employee.mealAllowanceDaily || 0),
    fixedDiscountPercent: employee.fixedDiscountPercent || "0",
  });
  uiState.pendingEmployeeDocuments = JSON.parse(JSON.stringify(employee.documents || []));
  renderPendingEmployeeDocuments();
  setupBRLInputs(form);
}

function renderPendingEmployeeDocuments() {
  const container = document.getElementById("employeePendingDocsList");
  if (!container) return;
  const docs = uiState.pendingEmployeeDocuments || [];
  if (!docs.length) {
    container.innerHTML = '<li><span class="small">Nenhum documento anexado.</span></li>';
    return;
  }

  container.innerHTML = "";
  docs.forEach((doc) => {
    const li = document.createElement("li");
    li.innerHTML = `<span><strong>${escapeHtml(doc.name)}</strong> <span class="small">(${escapeHtml(formatFileSize(doc.size))})</span></span>`;
    const actions = document.createElement("div");
    actions.className = "exports-actions";

    const btnDownload = document.createElement("button");
    btnDownload.type = "button";
    btnDownload.className = "btn";
    btnDownload.textContent = "Baixar";
    btnDownload.addEventListener("click", () => {
      fetch(doc.dataUrl)
        .then((response) => response.blob())
        .then((blob) => downloadBlob(doc.name, blob));
    });

    const btnRemove = document.createElement("button");
    btnRemove.type = "button";
    btnRemove.className = "btn btn-danger";
    btnRemove.textContent = "Remover";
    btnRemove.addEventListener("click", () => {
      uiState.pendingEmployeeDocuments = docs.filter((item) => item.id !== doc.id);
      renderPendingEmployeeDocuments();
    });

    actions.appendChild(btnDownload);
    actions.appendChild(btnRemove);
    li.appendChild(actions);
    container.appendChild(li);
  });
}

function exportEmployeesCsv() {
  const employees = [...(state.payslipEmployees || [])].sort((a, b) =>
    a.employeeName.localeCompare(b.employeeName, "pt-BR"),
  );
  const headers = [
    "Nome",
    "CPF",
    "Cargo",
    "Matrícula",
    "Salário Base",
    "VA Fixo",
    "VA Diário",
    "Desconto Fixo (%)",
    "Qtd. Anexos",
  ];
  const rows = employees.map((employee) => [
    employee.employeeName,
    employee.employeeCpf || "",
    employee.position || "",
    employee.registration || "",
    Number(employee.baseSalary || 0).toFixed(2),
    Number(employee.mealAllowanceFixed || 0).toFixed(2),
    Number(employee.mealAllowanceDaily || 0).toFixed(2),
    String(employee.fixedDiscountPercent || "0"),
    String((employee.documents || []).length),
  ]);

  const csvEscape = (value) => `"${String(value || "").replaceAll('"', '""')}"`;
  const csv = [headers, ...rows].map((row) => row.map(csvEscape).join(";")).join("\n");
  downloadTextFile("funcionarios-vila-marques.csv", `\uFEFF${csv}`, "text/csv;charset=utf-8");
}

function exportEmployeeJson(employee) {
  const payload = {
    id: employee.id,
    nome: employee.employeeName,
    cpf: employee.employeeCpf || "",
    cargo: employee.position || "",
    matricula: employee.registration || "",
    salarioBase: Number(employee.baseSalary || 0),
    valeAlimentacaoFixo: Number(employee.mealAllowanceFixed || 0),
    valeAlimentacaoDiario: Number(employee.mealAllowanceDaily || 0),
    descontoFixoPercentual: Number(employee.fixedDiscountPercent || 0),
    anexos: (employee.documents || []).map((doc) => ({
      nome: doc.name,
      tipo: doc.type,
      tamanho: doc.size,
      conteudoBase64: doc.dataUrl,
    })),
  };
  const safeName = String(employee.employeeName || "funcionario")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "");
  downloadTextFile(`funcionario-${safeName || "arquivo"}.json`, JSON.stringify(payload, null, 2), "application/json;charset=utf-8");
}

function renderEmployeeCatalog() {
  const container = document.getElementById("employeeCatalogList");
  if (!container) return;

  const sorted = [...(state.payslipEmployees || [])]
    .sort((a, b) => a.employeeName.localeCompare(b.employeeName, "pt-BR"));

  if (!sorted.length) {
    container.innerHTML = '<div class="small">Nenhum funcionário cadastrado ainda.</div>';
    return;
  }

  const rows = sorted
    .map((employee) => `
      <tr>
        <td>${escapeHtml(employee.employeeName)}</td>
        <td>${escapeHtml(employee.employeeCpf || "-")}</td>
        <td>${escapeHtml(employee.position || "-")}</td>
        <td>${currencyBRL.format(Number(employee.baseSalary || 0))}</td>
        <td>${currencyBRL.format(Number(employee.mealAllowanceFixed || 0))}</td>
        <td>${currencyBRL.format(Number(employee.mealAllowanceDaily || 0))}</td>
        <td>${escapeHtml(employee.fixedDiscountPercent || "0")}%</td>
        <td>${escapeHtml(String((employee.documents || []).length))}</td>
        <td>
          <div class="exports-actions">
            <button type="button" class="btn" data-action="view-employee" data-employee-id="${escapeHtml(employee.id)}">Ver</button>
            <button type="button" class="btn" data-action="edit-employee" data-employee-id="${escapeHtml(employee.id)}">Editar</button>
            <button type="button" class="btn" data-action="use-employee" data-employee-id="${escapeHtml(employee.id)}">Usar no contracheque</button>
            <button type="button" class="btn" data-action="export-employee" data-employee-id="${escapeHtml(employee.id)}">Exportar</button>
            <button type="button" class="btn btn-danger" data-action="delete-employee" data-employee-id="${escapeHtml(employee.id)}">Apagar</button>
          </div>
        </td>
      </tr>
    `)
    .join("");

  container.innerHTML = `
    <table class="balance-table">
      <thead>
        <tr>
          <th>Nome</th>
          <th>CPF</th>
          <th>Cargo</th>
          <th>Salário base</th>
          <th>VA fixo</th>
          <th>VA diário</th>
          <th>Desc. fixo</th>
          <th>Anexos</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

function renderClientsModule() {
  const formContainer = document.getElementById("clientsFormContainer");
  const viewContainer = document.getElementById("clientsViewContainer");
  const listContainer = document.getElementById("clientCatalogList");
  if (!formContainer || !viewContainer || !listContainer) return;
  formContainer.classList.toggle("auth-hidden", !uiState.clientsFormOpen);
  viewContainer.classList.toggle("auth-hidden", !uiState.viewingClientId);
  listContainer.classList.toggle("auth-hidden", uiState.clientsFormOpen || Boolean(uiState.viewingClientId));
}

function renderEmployeesModule() {
  const formContainer = document.getElementById("employeesFormContainer");
  const viewContainer = document.getElementById("employeesViewContainer");
  const listContainer = document.getElementById("employeeCatalogList");
  if (!formContainer || !viewContainer || !listContainer) return;
  formContainer.classList.toggle("auth-hidden", !uiState.employeesFormOpen);
  viewContainer.classList.toggle("auth-hidden", !uiState.viewingEmployeeId);
  listContainer.classList.toggle("auth-hidden", uiState.employeesFormOpen || Boolean(uiState.viewingEmployeeId));
}

function renderClientDetailsView() {
  const container = document.getElementById("clientDetailsContent");
  if (!container) return;
  const client = getClientById(uiState.viewingClientId);
  if (!client) {
    container.innerHTML = '<div class="small">Cliente não encontrado.</div>';
    return;
  }
  const rows = [
    ["Nome / Razão social", client.clientName],
    ["CNPJ", client.clientCnpj],
    ["Contato responsável", client.clientContact],
    ["Celular", client.clientPhone],
    ["E-mail", client.clientEmail],
    ["Rua", client.clientStreet],
    ["Número", client.clientNumber],
    ["Complemento", client.clientComplement],
    ["Bairro", client.clientDistrict],
    ["Cidade", client.clientCity],
    ["Estado (UF)", client.clientState],
    ["CEP", client.clientZipCode],
    ["Observações", client.clientNotes],
  ]
    .map(([label, value]) => `<tr><th>${escapeHtml(label)}</th><td>${escapeHtml(String(value || "-"))}</td></tr>`)
    .join("");
  container.innerHTML = `
    <h3 style="margin-top: 0;">Visualização de Cliente</h3>
    <table class="balance-table">
      <tbody>${rows}</tbody>
    </table>
  `;
}

function renderEmployeeDetailsView() {
  const container = document.getElementById("employeeDetailsContent");
  if (!container) return;
  const employee = (state.payslipEmployees || []).find((item) => item.id === uiState.viewingEmployeeId);
  if (!employee) {
    container.innerHTML = '<div class="small">Funcionário não encontrado.</div>';
    return;
  }
  const rows = [
    ["Nome", employee.employeeName],
    ["CPF", employee.employeeCpf],
    ["Cargo", employee.position],
    ["Matrícula", employee.registration],
    ["Salário base", currencyBRL.format(Number(employee.baseSalary || 0))],
    ["Vale alimentação fixo", currencyBRL.format(Number(employee.mealAllowanceFixed || 0))],
    ["Vale alimentação diário", currencyBRL.format(Number(employee.mealAllowanceDaily || 0))],
    ["Descontos fixos (%)", `${String(employee.fixedDiscountPercent || "0")}%`],
    ["Qtd. de anexos", String((employee.documents || []).length)],
  ]
    .map(([label, value]) => `<tr><th>${escapeHtml(label)}</th><td>${escapeHtml(String(value || "-"))}</td></tr>`)
    .join("");
  container.innerHTML = `
    <h3 style="margin-top: 0;">Visualização de Funcionário</h3>
    <table class="balance-table">
      <tbody>${rows}</tbody>
    </table>
  `;
}

function renderPayslipModule() {
  const formContainer = document.getElementById("payslipFormContainer");
  if (!formContainer) return;
  formContainer.classList.toggle("auth-hidden", !uiState.payslipFormOpen);
}

function getClientById(clientId) {
  return (state.clients || []).find((item) => item.id === clientId) || null;
}

function getContractDisplayName(contractId) {
  const contract = (state.contractsPortfolio || []).find((item) => item.id === contractId);
  if (!contract) return "-";
  return String(contract.contractName || "").trim() || "Sem nome";
}

function resolveContractIdFromText(value) {
  const raw = String(value || "").trim();
  if (!raw) return "";
  const byId = (state.contractsPortfolio || []).find((item) => item.id === raw);
  if (byId) return byId.id;
  const normalized = raw.toLowerCase();
  const byName = (state.contractsPortfolio || []).find(
    (item) => String(item.contractName || "").trim().toLowerCase() === normalized,
  );
  return byName ? byName.id : "";
}

function renderClientSelects() {
  const proposalSelect = document.getElementById("proposalClientSelect");
  const contractsSelect = document.getElementById("contractsClientSelect");
  const options = [...(state.clients || [])]
    .sort((a, b) => a.clientName.localeCompare(b.clientName, "pt-BR"))
    .map((client) => `<option value="${escapeHtml(client.id)}">${escapeHtml(client.clientName)}</option>`)
    .join("");

  if (proposalSelect) {
    proposalSelect.innerHTML = `<option value="">Selecionar cliente salvo</option>${options}`;
    proposalSelect.value = String(state.company.clientId || "");
  }
  if (contractsSelect) {
    contractsSelect.innerHTML = `<option value="">Selecionar cliente salvo</option>${options}`;
    contractsSelect.value = String(state.contracts.clientId || "");
  }
}

function useClientInProposal(clientId) {
  const client = getClientById(clientId);
  if (!client) return;
  state.company = {
    clientId: client.id,
    name: client.clientName || "",
    cnpj: client.clientCnpj || "",
    contact: client.clientContact || "",
    phone: client.clientPhone || "",
    email: client.clientEmail || "",
    city: client.clientCity || "",
    notes: client.clientNotes || "",
  };
  saveState();
  renderAll();
}

function resetClientCatalogForm() {
  const form = document.getElementById("clientCatalogForm");
  if (!form) return;
  form.reset();
  uiState.editingClientId = "";
}

function setClientCatalogForm(client) {
  const form = document.getElementById("clientCatalogForm");
  if (!form || !client) return;
  uiState.editingClientId = String(client.id || "");
  setFormValues(form, {
    clientName: client.clientName || "",
    clientCnpj: client.clientCnpj || "",
    clientContact: client.clientContact || "",
    clientPhone: client.clientPhone || "",
    clientEmail: client.clientEmail || "",
    clientStreet: client.clientStreet || "",
    clientNumber: client.clientNumber || "",
    clientComplement: client.clientComplement || "",
    clientDistrict: client.clientDistrict || "",
    clientCity: client.clientCity || "",
    clientState: client.clientState || "",
    clientZipCode: client.clientZipCode || "",
    clientNotes: client.clientNotes || "",
  });
}

function renderClientCatalog() {
  const container = document.getElementById("clientCatalogList");
  if (!container) return;
  const sorted = [...(state.clients || [])].sort((a, b) => a.clientName.localeCompare(b.clientName, "pt-BR"));
  if (!sorted.length) {
    container.innerHTML = '<div class="small">Nenhum cliente cadastrado ainda.</div>';
    return;
  }

  const rows = sorted
    .map((client) => `
      <tr>
        <td>${escapeHtml(client.clientName || "-")}</td>
        <td>${escapeHtml(client.clientCnpj || "-")}</td>
        <td>${escapeHtml(client.clientContact || "-")}</td>
        <td>${escapeHtml(client.clientPhone || "-")}</td>
        <td>${escapeHtml(client.clientCity || "-")}</td>
        <td>
          <div class="exports-actions">
            <button type="button" class="btn" data-action="view-client" data-client-id="${escapeHtml(client.id)}">Ver</button>
            <button type="button" class="btn" data-action="edit-client" data-client-id="${escapeHtml(client.id)}">Editar</button>
            <button type="button" class="btn" data-action="use-client-proposal" data-client-id="${escapeHtml(client.id)}">Usar na proposta</button>
            <button type="button" class="btn btn-danger" data-action="delete-client" data-client-id="${escapeHtml(client.id)}">Apagar</button>
          </div>
        </td>
      </tr>
    `)
    .join("");

  container.innerHTML = `
    <table class="balance-table">
      <thead>
        <tr>
          <th>Cliente</th>
          <th>CNPJ</th>
          <th>Contato</th>
          <th>Celular</th>
          <th>Cidade</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

function dateWithClampedDay(year, monthIndex, dayOfMonth) {
  const lastDay = new Date(year, monthIndex + 1, 0).getDate();
  const day = Math.max(1, Math.min(lastDay, Number(dayOfMonth || 1)));
  return new Date(year, monthIndex, day);
}

function addMonthsSafe(date, months, dayOfMonth) {
  const targetYear = date.getFullYear();
  const targetMonth = date.getMonth() + months;
  const probe = new Date(targetYear, targetMonth, 1);
  return dateWithClampedDay(probe.getFullYear(), probe.getMonth(), dayOfMonth);
}

function calculateContractTimeline(contractData, referenceDate = new Date()) {
  const measurementStartDay = Number(contractData.measurementStartDay || 24);
  const measurementEndDay = Number(contractData.measurementEndDay || 24);
  const receiptDay = Number(contractData.receiptDay || 15);

  const now = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), referenceDate.getDate());
  const currentMonthStart = dateWithClampedDay(now.getFullYear(), now.getMonth(), measurementStartDay);
  let cycleStart = now >= currentMonthStart
    ? currentMonthStart
    : addMonthsSafe(currentMonthStart, -1, measurementStartDay);
  let cycleEnd = addMonthsSafe(cycleStart, 1, measurementEndDay);
  let receiptDate = dateWithClampedDay(cycleEnd.getFullYear(), cycleEnd.getMonth(), receiptDay);
  if (receiptDate <= cycleEnd) {
    receiptDate = addMonthsSafe(receiptDate, 1, receiptDay);
  }

  let guard = 0;
  while (receiptDate <= now && guard < 24) {
    cycleStart = addMonthsSafe(cycleStart, 1, measurementStartDay);
    cycleEnd = addMonthsSafe(cycleStart, 1, measurementEndDay);
    receiptDate = dateWithClampedDay(cycleEnd.getFullYear(), cycleEnd.getMonth(), receiptDay);
    if (receiptDate <= cycleEnd) {
      receiptDate = addMonthsSafe(receiptDate, 1, receiptDay);
    }
    guard += 1;
  }

  const toISODate = (date) => {
    const y = date.getFullYear();
    const m = String(date.getMonth() + 1).padStart(2, "0");
    const d = String(date.getDate()).padStart(2, "0");
    return `${y}-${m}-${d}`;
  };

  return {
    measurementStartDay,
    measurementEndDay,
    receiptDay,
    cycleStart,
    cycleEnd,
    receiptDate,
    cycleStartISO: toISODate(cycleStart),
    cycleEndISO: toISODate(cycleEnd),
    receiptDateISO: toISODate(receiptDate),
  };
}

function parseISODateOnly(value) {
  const raw = String(value || "").trim();
  if (!/^\d{4}-\d{2}-\d{2}$/.test(raw)) return null;
  const [y, m, d] = raw.split("-").map((part) => Number(part));
  const dt = new Date(y, m - 1, d);
  if (dt.getFullYear() !== y || dt.getMonth() !== m - 1 || dt.getDate() !== d) return null;
  return dt;
}

function toISODateOnly(date) {
  const y = date.getFullYear();
  const m = String(date.getMonth() + 1).padStart(2, "0");
  const d = String(date.getDate()).padStart(2, "0");
  return `${y}-${m}-${d}`;
}

function getContractNextReceiptDateISO(contractData) {
  const parsed = parseISODateOnly(contractData?.nextReceiptDateISO);
  if (parsed) return toISODateOnly(parsed);
  return calculateContractTimeline(contractData).receiptDateISO;
}

function isContractOverdue(contractData, referenceDate = new Date()) {
  const dueDate = parseISODateOnly(getContractNextReceiptDateISO(contractData));
  if (!dueDate) return false;
  const today = new Date(referenceDate.getFullYear(), referenceDate.getMonth(), referenceDate.getDate());
  return dueDate < today;
}

function advanceContractNextReceiptDate(currentDueISO, receiptDay) {
  const dueDate = parseISODateOnly(currentDueISO);
  if (!dueDate) return "";
  return toISODateOnly(addMonthsSafe(dueDate, 1, Number(receiptDay || 15)));
}

function registerContractPayment(contractData, paymentDateISO) {
  const normalized = normalizeContract(contractData);
  const dueDateISO = getContractNextReceiptDateISO(normalized);
  const history = Array.isArray(normalized.receiptHistory) ? [...normalized.receiptHistory] : [];
  history.push({
    id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    dueDateISO,
    paymentDateISO,
    createdAt: new Date().toISOString(),
  });
  return normalizeContract({
    ...normalized,
    receiptHistory: history,
    nextReceiptDateISO: advanceContractNextReceiptDate(dueDateISO, normalized.receiptDay),
    updatedAt: new Date().toISOString(),
  });
}

function getContractNotificationItems() {
  return (state.contractsPortfolio || [])
    .filter((item) => item.isEffective && hasContractContent(item) && isContractOverdue(item))
    .map((item) => ({
      id: item.id,
      contractName: item.contractName || "Sem nome",
      dueDateISO: getContractNextReceiptDateISO(item),
    }))
    .sort((a, b) => a.dueDateISO.localeCompare(b.dueDateISO));
}

function calculateContractsResult(contractData = state.contracts) {
  const timeline = calculateContractTimeline(contractData);
  const capacity = Number(contractData.capacity || 0);
  const dailyRatePerPerson = Number(contractData.dailyRatePerPerson || 0);
  const monthlyTaxPercent = Number(contractData.monthlyTaxPercent || 0);
  const monthlyRevenue = capacity * dailyRatePerPerson * 30;
  const monthlyTaxValue = monthlyRevenue * (monthlyTaxPercent / 100);

  const rentCost = Number(contractData.rentCost || 0);
  const staffCost = Number(contractData.staffCost || 0);
  const furnitureCost = Number(contractData.furnitureCost || 0);
  const cleaningProductsCost = Number(contractData.cleaningProductsCost || 0);
  const waterCost = Number(contractData.waterCost || 0);
  const electricityCost = Number(contractData.electricityCost || 0);
  const internetCost = Number(contractData.internetCost || 0);
  const maintenanceCost = Number(contractData.maintenanceCost || 0);
  const proLaboreCost = Number(contractData.proLaboreCost || 0);
  const proLaboreRecipient = String(contractData.proLaboreRecipient || "").trim();

  const recurringCosts =
    rentCost
    + staffCost
    + cleaningProductsCost
    + waterCost
    + electricityCost
    + internetCost
    + maintenanceCost
    + proLaboreCost
    + monthlyTaxValue;
  const monthlyProfit = monthlyRevenue - recurringCosts;
  const firstMonthProfit = monthlyProfit - furnitureCost;
  const breakEvenMonths =
    monthlyProfit > 0
      ? furnitureCost / monthlyProfit
      : null;

  return {
    capacity,
    dailyRatePerPerson,
    monthlyTaxPercent,
    monthlyTaxValue,
    monthlyRevenue,
    recurringCosts,
    proLaboreCost,
    proLaboreRecipient,
    furnitureCost,
    monthlyProfit,
    firstMonthProfit,
    breakEvenMonths,
    timeline,
  };
}

function getContractsFormPayload() {
  const contractsForm = document.getElementById("contractsForm");
  if (!contractsForm) return null;
  const payload = formToObject(contractsForm);
  CONTRACT_MONEY_FIELDS.forEach((field) => {
    payload[field] = String(parseBRLNumber(payload[field]));
  });
  return payload;
}

function resetContractsDraftForm(closeForm = true) {
  state.contracts = createEmptyContract();
  state.activeContractId = "";
  if (closeForm) uiState.contractsFormOpen = false;
  uiState.contractsEditMode = false;
  uiState.contractsSummaryVisible = false;
}

function saveContractFromForm({ isEffective }) {
  const payload = getContractsFormPayload();
  if (!payload) return false;
  const nowISO = new Date().toISOString();
  const existing = state.contractsPortfolio.find((item) => item.id === state.activeContractId) || null;
  const contractToSave = normalizeContract({
    ...(existing || createEmptyContract()),
    ...(payload || {}),
    id: existing ? existing.id : `${Date.now()}-${Math.random().toString(16).slice(2)}`,
    isEffective: Boolean(isEffective),
    createdAt: existing?.createdAt || nowISO,
    updatedAt: nowISO,
  });
  const idx = state.contractsPortfolio.findIndex((item) => item.id === contractToSave.id);
  if (idx >= 0) state.contractsPortfolio[idx] = contractToSave;
  else state.contractsPortfolio.push(contractToSave);
  resetContractsDraftForm(true);
  saveState();
  renderAll();
  return true;
}

function syncCurrentContractFromForm() {
  const payload = getContractsFormPayload();
  if (!payload) return;
  const currentId = state.activeContractId || state.contracts.id;
  state.contracts = normalizeContract({
    ...state.contracts,
    ...(payload || {}),
    id: currentId,
  });
}

function renderContractsOpenSummary() {
  const container = document.getElementById("contractsOpenSummary");
  if (!container) return;

  if (!uiState.contractsFormOpen) {
    container.innerHTML = "";
    return;
  }

  const result = calculateContractsResult(state.contracts);
  const nextReceiptISO = getContractNextReceiptDateISO(state.contracts);
  const isOverdue = isContractOverdue(state.contracts);
  const receiptHistory = [...(state.contracts.receiptHistory || [])]
    .sort((a, b) => b.dueDateISO.localeCompare(a.dueDateISO))
    .slice(0, 8);
  const breakEvenText = Number.isFinite(result.breakEvenMonths)
    ? `${Number(result.breakEvenMonths).toFixed(1)} meses`
    : "Sem previsão";
  const historyRows = receiptHistory.length
    ? receiptHistory
      .map((entry) => `
        <tr>
          <td>${formatDateBR(entry.dueDateISO)}</td>
          <td>${formatDateBR(entry.paymentDateISO)}</td>
          <td><span class="balance-income">Pago</span></td>
        </tr>
      `)
      .join("")
    : '<tr><td colspan="3" class="small">Nenhum recebimento marcado ainda.</td></tr>';

  container.classList.toggle("contracts-summary-hidden", !uiState.contractsSummaryVisible);
  container.innerHTML = `
    <div class="contracts-summary-toolbar">
      <h3 style="margin: 0;">Resumo Financeiro do Contrato</h3>
      <button id="btnToggleContractSummaryValues" type="button" class="btn ${uiState.contractsSummaryVisible ? "btn-primary" : ""}">
        ${uiState.contractsSummaryVisible ? "Ocultar resumo" : "Mostrar resumo"}
      </button>
    </div>
    <div class="contracts-summary-grid">
      <article class="contracts-summary-card">
        <div class="label">Investimento inicial (custo único)</div>
        <div class="value contracts-summary-sensitive">${currencyBRL.format(result.furnitureCost)}</div>
      </article>
      <article class="contracts-summary-card">
        <div class="label">Custos recorrentes mensais</div>
        <div class="value contracts-summary-sensitive">${currencyBRL.format(result.recurringCosts)}</div>
      </article>
      <article class="contracts-summary-card">
        <div class="label">Faturamento mensal</div>
        <div class="value contracts-summary-sensitive positive">${currencyBRL.format(result.monthlyRevenue)}</div>
      </article>
      <article class="contracts-summary-card">
        <div class="label">Lucro mensal</div>
        <div class="value contracts-summary-sensitive ${result.monthlyProfit >= 0 ? "positive" : "negative"}">${currencyBRL.format(result.monthlyProfit)}</div>
      </article>
      <article class="contracts-summary-card">
        <div class="label">Lucro do 1º mês (com investimento)</div>
        <div class="value contracts-summary-sensitive ${result.firstMonthProfit >= 0 ? "positive" : "negative"}">${currencyBRL.format(result.firstMonthProfit)}</div>
      </article>
      <article class="contracts-summary-card">
        <div class="label">Breakeven estimado</div>
        <div class="value contracts-summary-sensitive">${escapeHtml(breakEvenText)}</div>
      </article>
    </div>
    <div style="margin-top: 14px;">
      <h3 style="margin: 0 0 8px;">Resumo de Recebimentos Mensais</h3>
      <div class="contracts-summary-card" style="margin-bottom: 8px;">
        <div class="label">Próximo recebimento previsto</div>
        <div class="value contracts-summary-sensitive">${formatDateBR(nextReceiptISO)}${isOverdue ? '<span class="tag-overdue">Atrasado</span>' : ""}</div>
        ${uiState.contractsEditMode ? `
          <div style="margin-top: 8px;">
            <button id="btnMarkCurrentReceiptPaid" type="button" class="btn btn-primary">Marcar como pago</button>
          </div>
        ` : ""}
      </div>
      <table class="balance-table">
        <thead>
          <tr>
            <th>Competência (vencimento)</th>
            <th>Data de pagamento</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          ${historyRows}
        </tbody>
      </table>
    </div>
  `;
}

function confirmContractDelete(contractName) {
  const normalizedName = String(contractName || "Sem nome").trim() || "Sem nome";
  if (!confirm(`Tem certeza que deseja excluir o contrato "${normalizedName}"?`)) return false;
  const typed = String(prompt('Digite EXCLUIR para confirmar a exclusão do contrato:') || "").trim();
  if (typed !== "EXCLUIR") {
    alert("Exclusão cancelada. Digite EXCLUIR exatamente para confirmar.");
    return false;
  }
  return true;
}

function renderContracts() {
  ensureContractsPortfolio();
  const formContainer = document.getElementById("contractsFormContainer");
  const listContainer = document.getElementById("contractsSavedList");
  const btnShowEffective = document.getElementById("btnShowEffectiveContracts");
  const btnShowDraft = document.getElementById("btnShowDraftContracts");
  const listActions = document.getElementById("contractsListActions");
  const openActions = document.getElementById("contractsOpenActions");
  const topActions = document.getElementById("contractsTopActions");
  if (!formContainer || !listContainer || !btnShowEffective || !btnShowDraft) return;

  formContainer.classList.toggle("auth-hidden", !uiState.contractsFormOpen);
  if (topActions) topActions.classList.toggle("auth-hidden", uiState.contractsFormOpen && !uiState.contractsEditMode);
  if (listActions) listActions.classList.toggle("auth-hidden", uiState.contractsFormOpen);
  if (openActions) openActions.classList.toggle("auth-hidden", !uiState.contractsFormOpen);
  listContainer.classList.toggle("auth-hidden", uiState.contractsFormOpen);
  btnShowEffective.classList.toggle("btn-primary", uiState.contractsSavedView === "effective");
  btnShowDraft.classList.toggle("btn-primary", uiState.contractsSavedView === "draft");
  renderContractsOpenSummary();
  const btnToggleSummary = document.getElementById("btnToggleContractSummaryValues");
  if (btnToggleSummary) {
    btnToggleSummary.onclick = () => {
      uiState.contractsSummaryVisible = !uiState.contractsSummaryVisible;
      renderContractsOpenSummary();
    };
  }
  const btnMarkReceiptPaid = document.getElementById("btnMarkCurrentReceiptPaid");
  if (btnMarkReceiptPaid) {
    btnMarkReceiptPaid.onclick = () => {
      if (!state.activeContractId) {
        alert("Salve o contrato antes de marcar recebimento como pago.");
        return;
      }
      const todayISO = toISODateOnly(new Date());
      const typedDate = String(prompt("Informe a data do pagamento (AAAA-MM-DD):", todayISO) || "").trim();
      const paymentDate = parseISODateOnly(typedDate);
      if (!paymentDate) {
        alert("Data inválida. Use o formato AAAA-MM-DD.");
        return;
      }
      const paidContract = registerContractPayment(state.contracts, toISODateOnly(paymentDate));
      state.contracts = { ...paidContract };
      if (state.activeContractId) {
        const idx = state.contractsPortfolio.findIndex((item) => item.id === state.activeContractId);
        if (idx >= 0) state.contractsPortfolio[idx] = paidContract;
      }
      saveState();
      renderAll();
    };
  }

  const contractsForm = document.getElementById("contractsForm");
  if (contractsForm) {
    contractsForm.querySelectorAll("input, select, textarea").forEach((field) => {
      field.disabled = !uiState.contractsEditMode;
    });
  }

  const filtered = state.contractsPortfolio
    .filter((item) => (uiState.contractsSavedView === "effective" ? item.isEffective : !item.isEffective))
    .map((item) => ({ item, result: calculateContractsResult(item) }))
    .sort((a, b) => new Date(b.item.updatedAt).getTime() - new Date(a.item.updatedAt).getTime());

  if (!filtered.length) {
    listContainer.innerHTML = uiState.contractsSavedView === "effective"
      ? '<div class="small">Nenhum contrato efetivado.</div>'
      : '<div class="small">Nenhum contrato em rascunho.</div>';
    return;
  }

  const rows = filtered
    .map(({ item, result }) => {
      const clientName = getClientById(item.clientId)?.clientName || "-";
      const isVisible = Boolean(uiState.contractsVisibleValuesById?.[item.id]);
      const nextReceiptISO = getContractNextReceiptDateISO(item);
      const overdueTag = isContractOverdue(item) ? '<span class="tag-overdue">Atrasado</span>' : "";
      return `
      <tr>
        <td>${escapeHtml(item.contractName || "Sem nome")}</td>
        <td>${escapeHtml(clientName)}</td>
        <td>${formatDateBR(nextReceiptISO)} ${overdueTag}</td>
        <td class="contracts-sensitive-value ${isVisible ? "" : "contracts-sensitive-value-hidden"} balance-income">${currencyBRL.format(result.monthlyRevenue)}</td>
        <td class="contracts-sensitive-value ${isVisible ? "" : "contracts-sensitive-value-hidden"} ${result.monthlyProfit >= 0 ? "balance-income" : "balance-expense"}">${currencyBRL.format(result.monthlyProfit)}</td>
        <td>${formatDateTimeBR(item.updatedAt)}</td>
        <td>
          <div class="exports-actions">
            <button type="button" class="btn contracts-eye-btn" data-action="toggle-contract-values" data-contract-id="${escapeHtml(item.id)}" title="${isVisible ? "Ocultar valores" : "Mostrar valores"}" aria-label="${isVisible ? "Ocultar valores" : "Mostrar valores"}">${isVisible ? "◉" : "◎"}</button>
            <button type="button" class="btn" data-action="edit-contract" data-contract-id="${escapeHtml(item.id)}">Editar</button>
            <button type="button" class="btn" data-action="open-contract" data-contract-id="${escapeHtml(item.id)}">Abrir</button>
            <button type="button" class="btn btn-danger" data-action="delete-contract" data-contract-id="${escapeHtml(item.id)}">Excluir</button>
          </div>
        </td>
      </tr>
    `;
    })
    .join("");

  listContainer.innerHTML = `
    <table class="balance-table">
      <thead>
        <tr>
          <th>Contrato</th>
          <th>Cliente</th>
          <th>Próx. recebimento</th>
          <th>Faturamento mensal</th>
          <th>Lucro mensal</th>
          <th>Atualizado em</th>
          <th>Ações</th>
        </tr>
      </thead>
      <tbody>${rows}</tbody>
    </table>
  `;
}

function renderNotifications() {
  const btn = document.getElementById("btnNotifications");
  const badge = document.getElementById("notificationsBadge");
  const panel = document.getElementById("notificationsPanel");
  if (!btn || !badge || !panel) return;

  const items = getContractNotificationItems();
  const total = items.length;
  badge.textContent = String(total);
  badge.classList.toggle("auth-hidden", total <= 0);
  btn.classList.toggle("btn-primary", total > 0);
  panel.classList.toggle("auth-hidden", !uiState.notificationsOpen);

  if (!items.length) {
    panel.innerHTML = '<div class="small">Sem notificações pendentes.</div>';
    return;
  }

  panel.innerHTML = items
    .map((item) => `
      <article class="notification-item">
        <div><strong>${escapeHtml(item.contractName)}</strong> <span class="tag-overdue">Atrasado</span></div>
        <div class="small">Recebimento pendente desde ${formatDateBR(item.dueDateISO)}</div>
        <div style="margin-top: 8px;">
          <button type="button" class="btn btn-primary" data-action="open-notification-contract" data-contract-id="${escapeHtml(item.id)}">Abrir contrato</button>
        </div>
      </article>
    `)
    .join("");
}

function exportTypeLabel(type) {
  return type === "payslip" ? "Contra-cheque" : "Proposta Comercial";
}

function cloudStatusLabel(status) {
  if (status === "synced") return "Sincronizado";
  if (status === "failed") return "Falha";
  return "Pendente";
}

function renderExports() {
  const endpointInput = document.getElementById("cloudSyncEndpoint");
  const statusContainer = document.getElementById("cloudSyncStatus");
  const listContainer = document.getElementById("exportsList");
  if (!endpointInput || !statusContainer || !listContainer) return;

  endpointInput.value = getCloudSyncEndpoint();
  statusContainer.textContent = endpointInput.value
    ? "Endpoint configurado."
    : "Configure um endpoint para enviar os PDFs exportados para a nuvem.";

  const rows = [...(state.exports || [])]
    .sort((a, b) => new Date(b.exportedAt).getTime() - new Date(a.exportedAt).getTime())
    .map(
      (entry) => `
        <tr>
          <td>${escapeHtml(exportTypeLabel(entry.type))}</td>
          <td>${formatDateTimeBR(entry.exportedAt)}</td>
          <td>${escapeHtml(entry.companyName || "-")}</td>
          <td>${escapeHtml(entry.proposalNumber || "-")}</td>
          <td>${escapeHtml(cloudStatusLabel(entry.cloudStatus))}</td>
          <td>
            <div class="exports-actions">
              <button type="button" class="btn" data-action="edit-export" data-export-id="${escapeHtml(entry.id)}">Abrir para editar</button>
              <button type="button" class="btn" data-action="sync-export" data-export-id="${escapeHtml(entry.id)}">Sincronizar</button>
              <button type="button" class="btn btn-danger" data-action="delete-export" data-export-id="${escapeHtml(entry.id)}">Apagar</button>
            </div>
          </td>
        </tr>
      `,
    )
    .join("");

  listContainer.innerHTML = rows
    ? `
      <table class="balance-table">
        <thead>
          <tr>
            <th>Tipo</th>
            <th>Exportado em</th>
            <th>Cliente</th>
            <th>Nº Proposta</th>
            <th>Status nuvem</th>
            <th>Ações</th>
          </tr>
        </thead>
        <tbody>${rows}</tbody>
      </table>
    `
    : '<div class="small">Nenhum documento exportado ainda.</div>';
}

function loadExportForEditing(exportRecord) {
  if (!exportRecord || !exportRecord.snapshot) return;
  const snapshot = exportRecord.snapshot;

  if (exportRecord.type === "proposal") {
    state.company = cloneSnapshot(snapshot.company || {});
    state.clients = cloneSnapshot(snapshot.clients || state.clients || []);
    state.property = cloneSnapshot(snapshot.property || {});
    state.furniture = cloneSnapshot(snapshot.furniture || []);
    state.proposalPhotos = cloneSnapshot(snapshot.proposalPhotos || []);
    state.pricing = cloneSnapshot(snapshot.pricing || {});
    state.proposal = cloneSnapshot(snapshot.proposal || {});
    persistActiveContract({
      ...(getActiveContractRecord() || state.contracts),
      ...cloneSnapshot(snapshot.contracts || {}),
    });
    normalizeStatePatterns();
    saveState();
    renderAll();
    setActiveTab("proposals");
    setProposalStep(1);
    return;
  }

  if (exportRecord.type === "payslip") {
    state.payslip = {
      ...state.payslip,
      ...cloneSnapshot(snapshot.payslip || {}),
      earnings: cloneSnapshot((snapshot.payslip && snapshot.payslip.earnings) || []),
      discounts: cloneSnapshot((snapshot.payslip && snapshot.payslip.discounts) || []),
    };
    normalizeStatePatterns();
    saveState();
    uiState.payslipFormOpen = true;
    renderAll();
    setActiveTab("payslip");
  }
}

function renderAll() {
  ensureContractsPortfolio();
  setFormValues(document.getElementById("companyForm"), state.company);
  setFormValues(document.getElementById("propertyForm"), state.property);
  setFormValues(document.getElementById("pricingForm"), state.pricing);
  setFormValues(document.getElementById("proposalForm"), state.proposal);
  setFormValues(document.getElementById("payslipForm"), state.payslip);
  setFormValues(document.getElementById("contractsForm"), state.contracts);
  refreshBrazilianPatternInputs();
  setupBRLInputs(document.getElementById("clientCatalogForm"));
  setupBRLInputs(document.getElementById("employeeCatalogForm"));
  renderPendingEmployeeDocuments();
  renderProposalPhotosList();

  const contractsForm = document.getElementById("contractsForm");
  if (contractsForm) {
    CONTRACT_MONEY_FIELDS.forEach((field) => {
      const input = contractsForm.elements.namedItem(field);
      if (input) input.value = formatBRLInputValue(input.value);
    });
    setupBRLInputs(contractsForm);
  }

  renderFurnitureList();

  renderProposal();
  renderList(
    document.getElementById("earningList"),
    state.payslip.earnings,
    (item) => `${item.description}: ${currencyBRL.format(Number(item.value || 0))}`,
    (index) => removeByIndex(state.payslip.earnings, index),
  );
  renderList(
    document.getElementById("discountList"),
    state.payslip.discounts,
    (item) => `${item.description}: ${currencyBRL.format(Number(item.value || 0))}`,
    (index) => removeByIndex(state.payslip.discounts, index),
  );
  renderPayslip();
  renderPayslipModule();
  renderSavedPayslipEmployees();
  renderClientsModule();
  renderEmployeesModule();
  renderClientDetailsView();
  renderEmployeeDetailsView();
  renderClientSelects();
  renderClientCatalog();
  renderEmployeeCatalog();
  renderBalance();
  renderContracts();
  renderExports();
  renderNotifications();
}

function validatePayslipRequiredFields() {
  const payslipForm = document.getElementById("payslipForm");
  if (!payslipForm) return false;
  if (!payslipForm.reportValidity()) return false;

  const cpfInput = payslipForm.elements.namedItem("employeeCpf");
  if (cpfInput) {
    const cpfDigits = onlyDigits(cpfInput.value || "");
    if (cpfDigits.length !== 11) {
      alert("Preencha um CPF válido com 11 dígitos.");
      cpfInput.focus();
      return false;
    }
  }

  const monthTotalDays = Number(payslipForm.elements.namedItem("monthTotalDays")?.value || 0);
  const businessDays = Number(payslipForm.elements.namedItem("businessDaysInMonth")?.value || 0);
  const absenceDays = Number(payslipForm.elements.namedItem("absenceDays")?.value || 0);
  const allowanceDays = Number(payslipForm.elements.namedItem("allowanceDays")?.value || 0);
  if (monthTotalDays < 28 || monthTotalDays > 31) {
    alert("Dias totais do mês devem estar entre 28 e 31.");
    payslipForm.elements.namedItem("monthTotalDays")?.focus();
    return false;
  }
  if (businessDays <= 0) {
    alert("Informe os dias úteis do mês com valor maior que zero.");
    payslipForm.elements.namedItem("businessDaysInMonth")?.focus();
    return false;
  }
  if (absenceDays > businessDays) {
    alert("Faltas não podem ser maiores que os dias úteis do mês.");
    payslipForm.elements.namedItem("absenceDays")?.focus();
    return false;
  }
  if (allowanceDays > absenceDays) {
    alert("Dias de abono não podem ser maiores que os dias de falta.");
    payslipForm.elements.namedItem("allowanceDays")?.focus();
    return false;
  }

  return true;
}

function bindEvents() {
  const modulesToggle = document.getElementById("btnModulesToggle");
  const modulesMenu = document.getElementById("modulesMenu");
  const btnNotifications = document.getElementById("btnNotifications");
  const notificationsPanel = document.getElementById("notificationsPanel");
  if (modulesToggle && modulesMenu) {
    modulesToggle.addEventListener("click", (event) => {
      event.stopPropagation();
      const isHidden = modulesMenu.classList.contains("modules-menu-hidden");
      setModulesMenuOpen(isHidden);
    });
    document.addEventListener("click", (event) => {
      if (!(event.target instanceof HTMLElement)) return;
      if (modulesMenu.contains(event.target) || modulesToggle.contains(event.target)) return;
      setModulesMenuOpen(false);
      if (notificationsPanel && btnNotifications) {
        if (notificationsPanel.contains(event.target) || btnNotifications.contains(event.target)) return;
      }
      uiState.notificationsOpen = false;
      renderNotifications();
    });
  }
  if (btnNotifications && notificationsPanel) {
    btnNotifications.addEventListener("click", (event) => {
      event.stopPropagation();
      uiState.notificationsOpen = !uiState.notificationsOpen;
      renderNotifications();
    });
    notificationsPanel.addEventListener("click", (event) => {
      const target = event.target;
      if (!(target instanceof HTMLElement)) return;
      const button = target.closest("button[data-action='open-notification-contract']");
      if (!button) return;
      const contractId = String(button.getAttribute("data-contract-id") || "");
      if (!contractId) return;
      setActiveContractById(contractId);
      uiState.contractsFormOpen = true;
      uiState.contractsEditMode = false;
      uiState.contractsSummaryVisible = false;
      uiState.contractsSavedView = "effective";
      uiState.notificationsOpen = false;
      setActiveTab("contracts");
      renderAll();
    });
  }

  document.getElementById("authTabLogin").addEventListener("click", () => switchAuthTab("login"));
  document.getElementById("authTabSignup").addEventListener("click", () => switchAuthTab("signup"));
  document.getElementById("authTabForgot").addEventListener("click", () => switchAuthTab("forgot"));
  document.getElementById("btnToggleSupabaseConfig").addEventListener("click", () => {
    toggleSupabaseConfig();
  });
  document.getElementById("btnUseTestAccess").addEventListener("click", () => {
    setLocalTestSession(true);
    authState.mode = "local";
    authState.user = { email: LOCAL_TEST_EMAIL };
    showAppShell(true);
    setAuthMessage("Acesso de teste local ativado.");
  });

  document.getElementById("authConfigForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const url = String(document.getElementById("supabaseUrlInput").value || "").trim();
    const anon = String(document.getElementById("supabaseAnonKeyInput").value || "").trim();
    setLocalTestSession(false);
    setSupabaseConfig(url, anon);
    setAuthMessage("Configuração salva. Inicializando autenticação...");
    await initAuthClient();
  });

  document.getElementById("loginForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    if (!authState.client) {
      const isTestLogin =
        String(data.email || "").trim().toLowerCase() === LOCAL_TEST_EMAIL
        && String(data.password || "") === LOCAL_TEST_PASSWORD;
      if (isTestLogin) {
        setLocalTestSession(true);
        authState.mode = "local";
        authState.user = { email: LOCAL_TEST_EMAIL };
        showAppShell(true);
        setAuthMessage("Login de teste realizado.");
        return;
      }
      setAuthMessage("Configure o Supabase ou use o login de teste.", true);
      return;
    }
    const { error } = await authState.client.auth.signInWithPassword({
      email: data.email,
      password: data.password,
    });
    if (error) {
      setAuthMessage(error.message, true);
      return;
    }
    setAuthMessage("Login realizado com sucesso.");
  });

  document.getElementById("signupForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!authState.client) {
      setAuthMessage("Configure o Supabase antes do cadastro.", true);
      return;
    }
    const data = formToObject(event.currentTarget);
    const { error } = await authState.client.auth.signUp({
      email: data.email,
      password: data.password,
      options: { emailRedirectTo: getRedirectUrl() },
    });
    if (error) {
      setAuthMessage(error.message, true);
      return;
    }
    setAuthMessage("Cadastro enviado. Verifique seu e-mail para confirmar a conta.");
  });

  document.getElementById("forgotForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!authState.client) {
      setAuthMessage("Configure o Supabase antes de recuperar senha.", true);
      return;
    }
    const data = formToObject(event.currentTarget);
    const { error } = await authState.client.auth.resetPasswordForEmail(data.email, {
      redirectTo: getRedirectUrl(),
    });
    if (error) {
      setAuthMessage(error.message, true);
      return;
    }
    setAuthMessage("E-mail de recuperação enviado.");
  });

  document.getElementById("resetForm").addEventListener("submit", async (event) => {
    event.preventDefault();
    if (!authState.client) {
      setAuthMessage("Configure o Supabase antes de redefinir senha.", true);
      return;
    }
    const data = formToObject(event.currentTarget);
    const { error } = await authState.client.auth.updateUser({ password: data.password });
    if (error) {
      setAuthMessage(error.message, true);
      return;
    }
    setAuthMessage("Senha atualizada. Faça login novamente.");
    switchAuthTab("login");
    if (window.location.hash) window.history.replaceState({}, document.title, getRedirectUrl());
  });

  document.getElementById("btnLogout").addEventListener("click", async () => {
    setLocalTestSession(false);
    if (authState.client) await authState.client.auth.signOut();
    authState.user = null;
    authState.mode = "none";
    showAppShell(false);
    switchAuthTab("login");
    setAuthMessage("Sessão encerrada.");
  });

  document.getElementById("tabProposals").addEventListener("click", () => {
    setActiveTab("proposals");
  });

  document.getElementById("tabClients").addEventListener("click", () => {
    setActiveTab("clients");
  });

  document.getElementById("tabPayslip").addEventListener("click", () => {
    setActiveTab("payslip");
    renderPayslipModule();
  });

  document.getElementById("tabEmployees").addEventListener("click", () => {
    setActiveTab("employees");
  });

  document.getElementById("tabBalance").addEventListener("click", () => {
    setActiveTab("balance");
  });

  document.getElementById("tabContracts").addEventListener("click", () => {
    setActiveTab("contracts");
    renderContracts();
  });

  document.getElementById("tabExports").addEventListener("click", () => {
    setActiveTab("exports");
    renderExports();
  });

  document.getElementById("btnBalanceMonthly").addEventListener("click", () => {
    uiState.balanceMode = "monthly";
    renderBalance();
  });

  document.getElementById("btnBalanceYearly").addEventListener("click", () => {
    uiState.balanceMode = "yearly";
    renderBalance();
  });

  document.getElementById("balanceYearSelect").addEventListener("change", (event) => {
    uiState.balanceYear = Number(event.currentTarget.value || uiState.balanceYear);
    renderBalance();
  });

  document.getElementById("balanceMonthSelect").addEventListener("change", (event) => {
    uiState.balanceMonth = Number(event.currentTarget.value || uiState.balanceMonth);
    renderBalance();
  });

  document.getElementById("balanceContractSelect").addEventListener("change", (event) => {
    uiState.balanceContractId = String(event.currentTarget.value || "");
    renderBalance();
  });

  document.getElementById("btnPrevStep").addEventListener("click", () => {
    setProposalStep(uiState.proposalStep - 1);
  });

  document.getElementById("btnNextStep").addEventListener("click", () => {
    setProposalStep(uiState.proposalStep + 1);
  });

  document.querySelectorAll(".step-chip").forEach((chip) => {
    chip.addEventListener("click", () => {
      setProposalStep(Number(chip.getAttribute("data-step-jump")));
    });
  });

  setActiveTab("proposals");
  setProposalStep(1);

  renderDefaultFurnitureOptions();

  document.querySelectorAll("input[name]").forEach((input) => {
    if (input.dataset.brPatternBound === "1") return;
    input.dataset.brPatternBound = "1";
    applyBrazilianInputPattern(input, "input");
    input.addEventListener("input", () => {
      applyBrazilianInputPattern(input, "input");
    });
    input.addEventListener("blur", () => {
      applyBrazilianInputPattern(input, "blur");
    });
  });

  const companyForm = document.getElementById("companyForm");
  const persistCompanyForm = () => {
    const currentClientId = String(state.company.clientId || "");
    state.company = formToObject(companyForm);
    state.company.clientId = currentClientId;
    state.company.cnpj = formatCNPJ(state.company.cnpj);
    state.company.phone = formatPhoneBR(state.company.phone);
    state.company.email = String(state.company.email || "").trim().toLowerCase();
    saveState();
    renderProposal();
  };
  companyForm.addEventListener("submit", (event) => {
    event.preventDefault();
    persistCompanyForm();
    renderAll();
  });
  companyForm.addEventListener("input", () => {
    persistCompanyForm();
  });
  companyForm.addEventListener("change", () => {
    persistCompanyForm();
  });

  document.getElementById("btnUseSelectedClientInProposal").addEventListener("click", () => {
    const select = document.getElementById("proposalClientSelect");
    const clientId = String(select?.value || "");
    if (!clientId) {
      alert("Selecione um cliente para usar na proposta.");
      return;
    }
    useClientInProposal(clientId);
  });

  const clientCatalogForm = document.getElementById("clientCatalogForm");
  const persistClientCatalogForm = () => {
    const data = formToObject(clientCatalogForm);
    data.clientCnpj = formatCNPJ(data.clientCnpj);
    data.clientPhone = formatPhoneBR(data.clientPhone);
    data.clientZipCode = formatCEP(data.clientZipCode);
    data.clientState = String(data.clientState || "")
      .toUpperCase()
      .replace(/[^A-Z]/g, "")
      .slice(0, 2);
    data.clientEmail = String(data.clientEmail || "").trim().toLowerCase();
    setFormValues(clientCatalogForm, data);
    return data;
  };
  clientCatalogForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = persistClientCatalogForm();
    const clientName = String(data.clientName || "").trim();
    if (!clientName) {
      alert("Preencha o nome do cliente.");
      return;
    }

    const payload = {
      id: uiState.editingClientId || `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      clientName,
      clientCnpj: String(data.clientCnpj || ""),
      clientContact: String(data.clientContact || "").trim(),
      clientPhone: String(data.clientPhone || ""),
      clientEmail: String(data.clientEmail || ""),
      clientStreet: String(data.clientStreet || "").trim(),
      clientNumber: String(data.clientNumber || "").trim(),
      clientComplement: String(data.clientComplement || "").trim(),
      clientDistrict: String(data.clientDistrict || "").trim(),
      clientCity: String(data.clientCity || "").trim(),
      clientState: String(data.clientState || "").trim(),
      clientZipCode: String(data.clientZipCode || "").trim(),
      clientNotes: String(data.clientNotes || "").trim(),
    };

    const existingIndex = state.clients.findIndex((item) => item.id === payload.id);
    const duplicateCnpjIndex = state.clients.findIndex(
      (item) => item.clientCnpj && item.clientCnpj === payload.clientCnpj && item.id !== payload.id,
    );
    if (duplicateCnpjIndex >= 0) {
      payload.id = state.clients[duplicateCnpjIndex].id;
    }

    if (existingIndex >= 0) state.clients[existingIndex] = payload;
    else if (duplicateCnpjIndex >= 0) state.clients[duplicateCnpjIndex] = payload;
    else state.clients.push(payload);

    saveState();
    uiState.clientsFormOpen = false;
    uiState.viewingClientId = "";
    resetClientCatalogForm();
    renderAll();
    alert("Cliente salvo com sucesso.");
  });

  document.getElementById("clientCatalogList").addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest("button[data-action]");
    if (!button) return;
    const action = button.getAttribute("data-action");
    const clientId = String(button.getAttribute("data-client-id") || "");
    if (!clientId) return;
    const client = getClientById(clientId);
    if (!client) return;

    if (action === "view-client") {
      uiState.clientsFormOpen = false;
      uiState.viewingClientId = client.id;
      renderAll();
      return;
    }

    if (action === "edit-client") {
      uiState.viewingClientId = "";
      uiState.clientsFormOpen = true;
      setClientCatalogForm(client);
      renderAll();
      return;
    }

    if (action === "use-client-proposal") {
      useClientInProposal(client.id);
      setActiveTab("proposals");
      return;
    }

    if (action === "delete-client") {
      if (!confirm("Deseja apagar este cliente salvo?")) return;
      state.clients = state.clients.filter((item) => item.id !== client.id);
      if (uiState.viewingClientId === client.id) uiState.viewingClientId = "";
      state.contractsPortfolio = state.contractsPortfolio.map((contract) => (
        contract.clientId === client.id ? { ...contract, clientId: "" } : contract
      ));
      if (state.contracts.clientId === client.id) state.contracts.clientId = "";
      saveState();
      renderAll();
    }
  });

  const propertyForm = document.getElementById("propertyForm");
  const persistPropertyForm = () => {
    state.property = formToObject(propertyForm);
    state.property.zipCode = formatCEP(state.property.zipCode);
    state.property.state = String(state.property.state || "")
      .toUpperCase()
      .replace(/[^A-Z]/g, "")
      .slice(0, 2);
    saveState();
    renderProposal();
  };
  propertyForm.addEventListener("submit", (event) => {
    event.preventDefault();
    persistPropertyForm();
    renderAll();
  });
  propertyForm.addEventListener("input", () => {
    persistPropertyForm();
  });
  propertyForm.addEventListener("change", () => {
    persistPropertyForm();
  });

  const pricingForm = document.getElementById("pricingForm");
  pricingForm.addEventListener("submit", (event) => {
    event.preventDefault();
    state.pricing = formToObject(event.currentTarget);
    saveState();
    renderAll();
  });

  pricingForm.addEventListener("input", () => {
    state.pricing = formToObject(pricingForm);
    saveState();
    renderProposal();
  });

  pricingForm.addEventListener("change", () => {
    state.pricing = formToObject(pricingForm);
    saveState();
    renderProposal();
  });

  const proposalForm = document.getElementById("proposalForm");
  proposalForm.addEventListener("submit", (event) => {
    event.preventDefault();
    state.proposal = formToObject(event.currentTarget);
    saveState();
    renderAll();
  });

  proposalForm.addEventListener("input", () => {
    const next = formToObject(proposalForm);
    const day = Number(next.paymentDay || 0);
    next.paymentDay = day >= 1 && day <= 31 ? String(day) : "";
    state.proposal = next;
    saveState();
    renderProposal();
  });

  proposalForm.addEventListener("change", () => {
    const next = formToObject(proposalForm);
    const day = Number(next.paymentDay || 0);
    next.paymentDay = day >= 1 && day <= 31 ? String(day) : "";
    state.proposal = next;
    saveState();
    renderProposal();
  });

  const payslipForm = document.getElementById("payslipForm");
  payslipForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const next = formToObject(event.currentTarget);
    state.payslip = {
      ...state.payslip,
      ...next,
      employeeCpf: formatCPF(next.employeeCpf),
    };
    saveState();
    renderAll();
  });

  payslipForm.addEventListener("input", () => {
    const next = formToObject(payslipForm);
    state.payslip = {
      ...state.payslip,
      ...next,
      employeeCpf: formatCPF(next.employeeCpf),
    };
    saveState();
    renderPayslip();
  });

  document.getElementById("earningForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    state.payslip.earnings.push({
      description: data.description,
      value: Number(data.value || 0),
    });
    event.currentTarget.reset();
    saveState();
    renderAll();
  });

  document.getElementById("discountForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    state.payslip.discounts.push({
      description: data.description,
      value: Number(data.value || 0),
    });
    event.currentTarget.reset();
    saveState();
    renderAll();
  });

  document.getElementById("btnOpenEmployeesTab").addEventListener("click", () => {
    uiState.employeesFormOpen = true;
    setActiveTab("employees");
    renderAll();
  });

  document.getElementById("btnNewPayslip").addEventListener("click", () => {
    uiState.payslipFormOpen = true;
    setActiveTab("payslip");
    renderAll();
    window.requestAnimationFrame(() => {
      const input = document.getElementById("payslipForm")?.elements?.namedItem("competence");
      if (input) input.focus();
    });
  });

  document.getElementById("btnBackToPayslipList").addEventListener("click", () => {
    uiState.payslipFormOpen = false;
    renderAll();
  });

  document.getElementById("btnNewClient").addEventListener("click", () => {
    uiState.clientsFormOpen = true;
    uiState.viewingClientId = "";
    uiState.editingClientId = "";
    resetClientCatalogForm();
    renderAll();
    window.requestAnimationFrame(() => {
      const input = document.getElementById("clientCatalogForm")?.elements?.namedItem("clientName");
      if (input) input.focus();
    });
  });

  document.getElementById("btnBackToClientsList").addEventListener("click", () => {
    uiState.clientsFormOpen = false;
    uiState.viewingClientId = "";
    resetClientCatalogForm();
    renderAll();
  });

  document.getElementById("btnBackFromClientView").addEventListener("click", () => {
    uiState.viewingClientId = "";
    renderAll();
  });

  document.getElementById("btnNewEmployee").addEventListener("click", () => {
    uiState.employeesFormOpen = true;
    uiState.viewingEmployeeId = "";
    uiState.editingEmployeeId = "";
    resetEmployeeCatalogForm();
    renderAll();
    window.requestAnimationFrame(() => {
      const input = document.getElementById("employeeCatalogForm")?.elements?.namedItem("employeeName");
      if (input) input.focus();
    });
  });

  document.getElementById("btnBackToEmployeesList").addEventListener("click", () => {
    uiState.employeesFormOpen = false;
    uiState.viewingEmployeeId = "";
    resetEmployeeCatalogForm();
    renderAll();
  });

  document.getElementById("btnBackFromEmployeeView").addEventListener("click", () => {
    uiState.viewingEmployeeId = "";
    renderAll();
  });

  document.getElementById("savedPayslipEmployeeSelect").addEventListener("change", (event) => {
    const employeeId = String(event.currentTarget.value || "");
    if (!employeeId) {
      state.payslip.selectedEmployeeId = "";
      saveState();
      return;
    }
    uiState.payslipFormOpen = true;
    loadSavedPayslipEmployee(employeeId);
  });

  const employeeCatalogForm = document.getElementById("employeeCatalogForm");
  setupBRLInputs(employeeCatalogForm);
  const employeeDocsInput = document.getElementById("employeeDocsInput");
  if (employeeDocsInput) {
    employeeDocsInput.addEventListener("change", async () => {
      await addEmployeeDocumentsFromFiles(employeeDocsInput.files);
      employeeDocsInput.value = "";
    });
  }
  employeeCatalogForm.addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(employeeCatalogForm);
    const employeeName = String(data.employeeName || "").trim();
    const employeeCpf = formatCPF(data.employeeCpf || "");
    if (!employeeName || !employeeCpf) {
      alert("Preencha nome e CPF do funcionário.");
      return;
    }

    const payload = {
      id: uiState.editingEmployeeId || `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      employeeName,
      employeeCpf,
      position: String(data.position || "").trim(),
      registration: String(data.registration || "").trim(),
      baseSalary: String(parseBRLNumber(data.baseSalary || 0)),
      mealAllowanceFixed: String(parseBRLNumber(data.mealAllowanceFixed || 0)),
      mealAllowanceDaily: String(parseBRLNumber(data.mealAllowanceDaily || 0)),
      fixedDiscountPercent: String(Number(data.fixedDiscountPercent || 0)),
      documents: JSON.parse(JSON.stringify(uiState.pendingEmployeeDocuments || [])),
    };

    const existingIndex = state.payslipEmployees.findIndex((employee) => employee.id === payload.id);
    const duplicateCpfIndex = state.payslipEmployees.findIndex(
      (employee) => employee.employeeCpf === payload.employeeCpf && employee.id !== payload.id,
    );
    if (duplicateCpfIndex >= 0) {
      payload.id = state.payslipEmployees[duplicateCpfIndex].id;
    }

    if (existingIndex >= 0) {
      state.payslipEmployees[existingIndex] = payload;
    } else if (duplicateCpfIndex >= 0) {
      state.payslipEmployees[duplicateCpfIndex] = payload;
    } else {
      state.payslipEmployees.push(payload);
    }

    if (state.payslip.selectedEmployeeId === payload.id) {
      uiState.employeesFormOpen = false;
      uiState.viewingEmployeeId = "";
      loadSavedPayslipEmployee(payload.id);
      return;
    }

    saveState();
    uiState.employeesFormOpen = false;
    uiState.viewingEmployeeId = "";
    resetEmployeeCatalogForm();
    renderAll();
    alert("Funcionário salvo com sucesso.");
  });

  document.getElementById("employeeCatalogList").addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest("button[data-action]");
    if (!button) return;
    const action = button.getAttribute("data-action");
    const employeeId = button.getAttribute("data-employee-id");
    if (!employeeId) return;

    const employee = state.payslipEmployees.find((item) => item.id === employeeId);
    if (!employee) return;

    if (action === "view-employee") {
      uiState.employeesFormOpen = false;
      uiState.viewingEmployeeId = employee.id;
      renderAll();
      return;
    }

    if (action === "edit-employee") {
      uiState.viewingEmployeeId = "";
      uiState.employeesFormOpen = true;
      setEmployeeCatalogForm(employee);
      renderAll();
      return;
    }

    if (action === "use-employee") {
      uiState.payslipFormOpen = true;
      loadSavedPayslipEmployee(employee.id);
      setActiveTab("payslip");
      return;
    }

    if (action === "export-employee") {
      exportEmployeeJson(employee);
      return;
    }

    if (action === "delete-employee") {
      if (!confirm("Deseja apagar este funcionário salvo?")) return;
      state.payslipEmployees = state.payslipEmployees.filter((item) => item.id !== employee.id);
      if (uiState.viewingEmployeeId === employee.id) uiState.viewingEmployeeId = "";
      if (state.payslip.selectedEmployeeId === employee.id) {
        state.payslip.selectedEmployeeId = "";
      }
      saveState();
      renderAll();
    }
  });

  document.getElementById("btnExportEmployeesCsv").addEventListener("click", () => {
    exportEmployeesCsv();
  });

  document.getElementById("incomeForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    state.balance.entries.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type: "income",
      description: data.description,
      amount: Number(data.amount || 0),
      dateTime: data.dateTime,
      responsible: "",
      contractId: "",
    });
    event.currentTarget.reset();
    saveState();
    renderBalance();
  });

  document.getElementById("expenseForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    state.balance.entries.push({
      id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
      type: "expense",
      description: data.description,
      amount: Number(data.amount || 0),
      dateTime: data.dateTime,
      responsible: data.responsible,
      contractId: String(data.contractId || ""),
    });
    event.currentTarget.reset();
    saveState();
    renderBalance();
  });

  document.getElementById("expenseBatchForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    const lines = String(data.batchText || "")
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean);
    if (!lines.length) return;

    let imported = 0;
    lines.forEach((line) => {
      const parts = line.split(";").map((part) => part.trim());
      if (parts.length < 3) return;
      const description = parts[0];
      const amount = Number(String(parts[1]).replace(",", "."));
      const dateTime = parts[2];
      const responsible = parts[3] || "";
      const contractId = resolveContractIdFromText(parts[4] || "");
      if (!description || !Number.isFinite(amount) || amount < 0 || !dateTime) return;

      state.balance.entries.push({
        id: `${Date.now()}-${Math.random().toString(16).slice(2)}`,
        type: "expense",
        description,
        amount,
        dateTime,
        responsible,
        contractId,
      });
      imported += 1;
    });

    if (!imported) {
      alert("Nenhuma linha válida para importar.");
      return;
    }

    saveState();
    event.currentTarget.reset();
    renderBalance();
    alert(`${imported} despesa(s) importada(s) com sucesso.`);
  });

  const contractsForm = document.getElementById("contractsForm");
  setupBRLInputs(contractsForm);
  const contractsClientSelect = document.getElementById("contractsClientSelect");
  if (contractsClientSelect) {
    contractsClientSelect.addEventListener("change", () => {
      state.contracts.clientId = String(contractsClientSelect.value || "");
      renderContractsOpenSummary();
    });
  }
  contractsForm.addEventListener("submit", (event) => {
    event.preventDefault();
  });
  contractsForm.addEventListener("input", () => {
    syncCurrentContractFromForm();
    renderContractsOpenSummary();
  });
  contractsForm.addEventListener("change", () => {
    syncCurrentContractFromForm();
    renderContractsOpenSummary();
  });

  document.getElementById("btnNewContract").addEventListener("click", () => {
    uiState.contractsFormOpen = true;
    uiState.contractsEditMode = true;
    uiState.contractsSummaryVisible = false;
    state.activeContractId = "";
    state.contracts = createEmptyContract();
    renderAll();
    window.requestAnimationFrame(() => {
      const contractNameInput = contractsForm?.elements?.namedItem("contractName");
      if (contractNameInput) contractNameInput.focus();
    });
  });

  document.getElementById("btnSaveContractDraft").addEventListener("click", () => {
    if (!uiState.contractsEditMode) return;
    uiState.contractsSavedView = "draft";
    saveContractFromForm({ isEffective: false });
  });

  document.getElementById("btnSaveContract").addEventListener("click", () => {
    if (!uiState.contractsEditMode) return;
    uiState.contractsSavedView = "effective";
    saveContractFromForm({ isEffective: true });
  });

  document.getElementById("btnBackToContractsList").addEventListener("click", () => {
    uiState.contractsFormOpen = false;
    uiState.contractsEditMode = false;
    uiState.contractsSummaryVisible = false;
    renderContracts();
  });

  document.getElementById("btnShowEffectiveContracts").addEventListener("click", () => {
    uiState.contractsSavedView = "effective";
    renderContracts();
  });

  document.getElementById("btnShowDraftContracts").addEventListener("click", () => {
    uiState.contractsSavedView = "draft";
    renderContracts();
  });

  document.getElementById("contractsSavedList").addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest("button[data-action]");
    if (!button) return;
    const action = String(button.getAttribute("data-action") || "");
    const contractId = String(button.getAttribute("data-contract-id") || "");
    if (!contractId) return;

    if (action === "toggle-contract-values") {
      uiState.contractsVisibleValuesById[contractId] = !Boolean(uiState.contractsVisibleValuesById[contractId]);
      renderContracts();
      return;
    }

    if (action === "edit-contract") {
      setActiveContractById(contractId);
      uiState.contractsFormOpen = true;
      uiState.contractsEditMode = true;
      uiState.contractsSummaryVisible = false;
      renderAll();
      return;
    }

    if (action === "open-contract") {
      setActiveContractById(contractId);
      uiState.contractsFormOpen = true;
      uiState.contractsEditMode = false;
      uiState.contractsSummaryVisible = false;
      renderAll();
      return;
    }

    if (action === "delete-contract") {
      const contract = state.contractsPortfolio.find((item) => item.id === contractId);
      if (!contract) return;
      if (!confirmContractDelete(contract.contractName || "Sem nome")) return;
      state.contractsPortfolio = state.contractsPortfolio.filter((item) => item.id !== contractId);
      delete uiState.contractsVisibleValuesById[contractId];
      if (state.activeContractId === contractId) {
        resetContractsDraftForm(true);
      }
      saveState();
      renderAll();
    }
  });

  document.getElementById("furnitureForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const data = formToObject(event.currentTarget);
    upsertFurnitureItem(
      data.item,
      data.environment,
      Number(data.quantity || 1),
      data.notes,
    );
    const newNotes = String(data.notes || "").trim();
    if (newNotes) {
      const inserted = state.furniture.find(
        (x) =>
          x.item === String(data.item || "").trim()
          && x.environment === String(data.environment || "").trim()
          && String(x.notes || "").trim() === newNotes,
      );
      if (inserted) inserted.notes = newNotes;
    }
    event.currentTarget.reset();
    saveState();
    renderAll();
  });

  const photosInput = document.getElementById("proposalPhotosInput");
  const photosCameraInput = document.getElementById("proposalPhotosCameraInput");
  const btnSelectPhotos = document.getElementById("btnSelectPhotos");
  const btnTakePhoto = document.getElementById("btnTakePhoto");

  if (btnSelectPhotos && photosInput) {
    btnSelectPhotos.addEventListener("click", () => {
      photosInput.click();
    });
  }

  if (btnTakePhoto && photosCameraInput) {
    btnTakePhoto.addEventListener("click", () => {
      photosCameraInput.click();
    });
  }

  if (photosInput) {
    photosInput.addEventListener("change", async () => {
      await addProposalPhotosFromFiles(photosInput.files);
      photosInput.value = "";
    });
  }

  if (photosCameraInput) {
    photosCameraInput.addEventListener("change", async () => {
      await addProposalPhotosFromFiles(photosCameraInput.files);
      photosCameraInput.value = "";
    });
  }

  const btnAddSelectedFurniture = document.getElementById("btnAddSelectedFurniture");
  if (btnAddSelectedFurniture) {
    btnAddSelectedFurniture.addEventListener("click", () => {
      const checkboxes = Array.from(
        document.querySelectorAll(".default-furniture-checkbox:checked"),
      );

      if (!checkboxes.length) return;

      checkboxes.forEach((checkbox) => {
        const idx = Number(checkbox.getAttribute("data-default-index"));
        const item = DEFAULT_FURNITURE[idx];
        const qtyInput = document.querySelector(
          `.default-furniture-qty[data-default-qty-index="${idx}"]`,
        );
        const parsedQty = Number.parseInt(String(qtyInput?.value || "1"), 10);
        const qty = Number.isFinite(parsedQty) && parsedQty > 0 ? parsedQty : 1;
        const variantInput = document.querySelector(
          `.default-furniture-variant[data-default-variant-index="${idx}"]`,
        );
        const variantValue = String(variantInput?.value || "").trim();
        const variantConfig = FURNITURE_VARIANTS[item?.item];
        const variantNote = variantValue && variantConfig
          ? `${variantConfig.label}: ${variantValue}`
          : "";
        if (!item) return;
        upsertFurnitureItem(item.item, item.environment, qty, variantNote);
        checkbox.checked = false;
        if (qtyInput) qtyInput.value = "1";
      });

      saveState();
      renderAll();
    });
  }

  document.getElementById("btnExportPdf").addEventListener("click", () => {
    document.body.classList.remove("print-payslip");
    setActiveTab("proposals");
    setProposalStep(6);
    registerExport("proposal");
    window.print();
  });

  document.getElementById("btnExportPayslipPdf").addEventListener("click", () => {
    if (!validatePayslipRequiredFields()) return;
    setActiveTab("payslip");
    document.body.classList.add("print-payslip");
    renderPayslip();
    registerExport("payslip");
    window.requestAnimationFrame(() => {
      window.setTimeout(() => {
        window.print();
      }, 50);
    });
  });

  window.addEventListener("afterprint", () => {
    document.body.classList.remove("print-payslip");
  });

  document.getElementById("btnClear").addEventListener("click", () => {
    if (!confirm("Deseja limpar somente os campos da aba atual para um novo preenchimento?")) return;

    resetActiveTabInputs();
    saveState();
    if (uiState.activeTab === "proposals") {
      [
        "companyForm",
        "propertyForm",
        "pricingForm",
        "proposalForm",
        "furnitureForm",
      ].forEach((id) => document.getElementById(id)?.reset());
      const proposalPhotosInput = document.getElementById("proposalPhotosInput");
      const proposalPhotosCameraInput = document.getElementById("proposalPhotosCameraInput");
      if (proposalPhotosInput) proposalPhotosInput.value = "";
      if (proposalPhotosCameraInput) proposalPhotosCameraInput.value = "";
    } else if (uiState.activeTab === "payslip") {
      ["payslipForm", "earningForm", "discountForm"].forEach((id) => document.getElementById(id)?.reset());
      const savedEmployeeSelect = document.getElementById("savedPayslipEmployeeSelect");
      if (savedEmployeeSelect) savedEmployeeSelect.value = "";
    } else if (uiState.activeTab === "clients") {
      resetClientCatalogForm();
    } else if (uiState.activeTab === "employees") {
      resetEmployeeCatalogForm();
    } else if (uiState.activeTab === "balance") {
      ["incomeForm", "expenseForm"].forEach((id) => document.getElementById(id)?.reset());
    } else if (uiState.activeTab === "contracts") {
      document.getElementById("contractsForm")?.reset();
    } else if (uiState.activeTab === "exports") {
      document.getElementById("cloudSyncForm")?.reset();
    }
    renderAll();
  });

  document.getElementById("cloudSyncForm").addEventListener("submit", (event) => {
    event.preventDefault();
    const endpoint = String(document.getElementById("cloudSyncEndpoint").value || "").trim();
    setCloudSyncEndpoint(endpoint);
    renderExports();
  });

  document.getElementById("exportsList").addEventListener("click", (event) => {
    const target = event.target;
    if (!(target instanceof HTMLElement)) return;
    const button = target.closest("button[data-action]");
    if (!button) return;

    const action = button.getAttribute("data-action");
    const exportId = button.getAttribute("data-export-id");
    if (!exportId) return;

    const exportRecord = (state.exports || []).find((entry) => entry.id === exportId);
    if (!exportRecord) return;

    if (action === "edit-export") {
      loadExportForEditing(exportRecord);
      return;
    }

    if (action === "sync-export") {
      exportRecord.cloudStatus = "pending";
      saveState();
      renderExports();
      void syncExportToCloud(exportRecord).then((ok) => {
        const idx = state.exports.findIndex((entry) => entry.id === exportId);
        if (idx < 0) return;
        state.exports[idx].cloudStatus = ok ? "synced" : "failed";
        saveState();
        renderExports();
      });
      return;
    }

    if (action === "delete-export") {
      if (!confirm("Deseja apagar este documento exportado do histórico?")) return;
      state.exports = (state.exports || []).filter((entry) => entry.id !== exportId);
      saveState();
      renderExports();
    }
  });

  document.getElementById("btnSample").addEventListener("click", () => {
    state.company = {
      name: "Empresa Exemplo S.A.",
      cnpj: "00.000.000/0001-00",
      contact: "Maria Souza",
      phone: "(11) 98888-7777",
      email: "contato@empresaexemplo.com.br",
      city: "São Paulo",
      notes: "Condições sujeitas a ajustes conforme volume de unidades e prazo contratual.",
    };

    state.property = {
      name: "Residencial Centro 101",
      type: "Apartamento",
      operationType: "Operacional",
      street: "Rua Exemplo",
      number: "123",
      complement: "Apto 101",
      district: "Centro",
      city: "São Paulo",
      state: "SP",
      zipCode: "01000-000",
      capacity: "4",
      bedrooms: "3",
      bathrooms: "2",
      garageSpots: "1",
      serviceAreaType: "Coberta",
      dailyRatePerPerson: "130",
      description: "Apartamento mobiliado com fácil acesso ao polo industrial.",
    };

    state.furniture = [
      { item: "Geladeira", environment: "Cozinha", quantity: 1 },
      { item: "Cama box", environment: "Quarto", quantity: 4 },
      { item: "TV Smart", environment: "Sala", quantity: 1 },
      { item: "Sofá", environment: "Sala", quantity: 1 },
      { item: "Multiuso", environment: "Quarto", quantity: 2 },
    ];

    state.pricing = {
      marginPercent: "12",
      adminFeePercent: "4",
      discount: "5",
      validUntil: "2026-04-30",
    };

    state.proposal = {
      proposalNumber: "VM-2026-001",
      issueDate: "2026-03-09",
      contractStartDate: "2026-03-10",
      contractEndDate: "2026-12-31",
      paymentDay: "10",
      recipient: "Gerência de RH",
    };

    state.payslip = {
      competence: "03/2026",
      paymentDate: "2026-03-30",
      paymentMethod: "PIX",
      selectedEmployeeId: "",
      monthTotalDays: "31",
      businessDaysInMonth: "22",
      absenceDays: "1",
      allowanceDays: "1",
      employeeName: "João da Silva",
      employeeCpf: "123.456.789-09",
      position: "Auxiliar de Serviços",
      registration: "VM-023",
      baseSalary: "2100",
      mealAllowanceFixed: "350",
      mealAllowanceDaily: "18",
      fixedDiscountPercent: "2",
      earnings: [
        { description: "Adicional noturno", value: 250 },
      ],
      discounts: [
        { description: "INSS", value: 180 },
        { description: "Adiantamento", value: 200 },
      ],
    };

    state.payslipEmployees = [
      {
        id: "emp-1",
        employeeName: "João da Silva",
        employeeCpf: "123.456.789-09",
        position: "Auxiliar de Serviços",
        registration: "VM-023",
        baseSalary: "2100",
        mealAllowanceFixed: "350",
        mealAllowanceDaily: "18",
        fixedDiscountPercent: "2",
      },
    ];

    state.balance = {
      entries: [
        {
          id: "b1",
          type: "income",
          description: "Recebimento contrato Empresa Exemplo",
          amount: 18500,
          dateTime: "2026-03-05T10:00",
          responsible: "",
        },
        {
          id: "b2",
          type: "expense",
          description: "Compra de itens de manutenção",
          amount: 1200,
          dateTime: "2026-03-06T14:30",
          responsible: "Fred Marques",
        },
      ],
    };

    const sampleContract = {
      contractName: "Casa Operacional A",
      capacity: "12",
      dailyRatePerPerson: "130",
      monthlyTaxPercent: "6",
      measurementStartDay: "24",
      measurementEndDay: "24",
      receiptDay: "15",
      rentCost: "4200",
      staffCost: "3800",
      furnitureCost: "1500",
      cleaningProductsCost: "650",
      waterCost: "500",
      electricityCost: "980",
      internetCost: "200",
      maintenanceCost: "700",
      proLaboreCost: "1800",
      proLaboreRecipient: "Fred Marques",
      isEffective: true,
    };
    const normalizedSampleContract = normalizeContract(sampleContract);
    state.contracts = normalizedSampleContract;
    state.contractsPortfolio = [normalizedSampleContract];
    state.activeContractId = normalizedSampleContract.id;

    saveState();
    renderAll();
  });
}

async function initializeApp() {
  loadState();
  normalizeStatePatterns();
  bindEvents();
  renderAll();
  await initAuthClient();
}

initializeApp();
